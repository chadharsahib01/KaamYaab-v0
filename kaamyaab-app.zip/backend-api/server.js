const express = require("express")
const cors = require("cors")
const WebSocket = require("ws")
const http = require("http")
const mongoose = require("mongoose")
const multer = require("multer")
const csv = require("csv-parser")
const fs = require("fs")

const app = express()
const server = http.createServer(app)
const wss = new WebSocket.Server({ server })

// Middleware
app.use(
  cors({
    origin: ["http://localhost:3000", "http://localhost:3001"], // Admin and User app URLs
    credentials: true,
  }),
)
app.use(express.json())

// File upload configuration
const upload = multer({ dest: "uploads/" })

// MongoDB connection
mongoose.connect("mongodb://localhost:27017/kaamyaab", {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})

// Schemas
const MCQSchema = new mongoose.Schema({
  question: { type: String, required: true },
  options: [{ type: String, required: true }],
  correctAnswer: { type: Number, required: true },
  explanation: { type: String, required: true },
  category: { type: String, required: true },
  difficulty: { type: String, enum: ["Easy", "Medium", "Hard"], required: true },
  subject: { type: String, required: true },
  isActive: { type: Boolean, default: true },
  createdBy: { type: String, required: true },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now },
})

const ExamSchema = new mongoose.Schema({
  title: { type: String, required: true },
  date: { type: String, required: true },
  time: { type: String, required: true },
  location: { type: String, required: true },
  category: { type: String, required: true },
  applicationDeadline: { type: String, required: true },
  fee: { type: String, required: true },
  posts: { type: Number, required: true },
  description: { type: String, required: true },
  isActive: { type: Boolean, default: true },
  createdBy: { type: String, required: true },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now },
})

const UserSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  selectedCategories: [{ type: String }],
  isActive: { type: Boolean, default: true },
  lastActive: { type: Date, default: Date.now },
  createdAt: { type: Date, default: Date.now },
})

const TestSessionSchema = new mongoose.Schema({
  userId: { type: String, required: true },
  mcqId: { type: String, required: true },
  score: { type: Number, required: true },
  timeSpent: { type: Number, required: true },
  category: { type: String, required: true },
  createdAt: { type: Date, default: Date.now },
})

const MCQ = mongoose.model("MCQ", MCQSchema)
const Exam = mongoose.model("Exam", ExamSchema)
const User = mongoose.model("User", UserSchema)
const TestSession = mongoose.model("TestSession", TestSessionSchema)

// WebSocket connections
const adminClients = new Set()
const userClients = new Set()

wss.on("connection", (ws, req) => {
  const url = new URL(req.url, `http://${req.headers.host}`)
  const clientType = url.pathname.includes("admin") ? "admin" : "user"

  if (clientType === "admin") {
    adminClients.add(ws)
    console.log("Admin client connected")
  } else {
    userClients.add(ws)
    console.log("User client connected")
  }

  ws.on("close", () => {
    adminClients.delete(ws)
    userClients.delete(ws)
    console.log(`${clientType} client disconnected`)
  })
})

// Broadcast to all clients
function broadcastToAdmins(type, payload) {
  adminClients.forEach((client) => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(JSON.stringify({ type, payload }))
    }
  })
}

function broadcastToUsers(type, payload) {
  userClients.forEach((client) => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(JSON.stringify({ type, payload }))
    }
  })
}

function broadcastToAll(type, payload) {
  broadcastToAdmins(type, payload)
  broadcastToUsers(type, payload)
}

// Authentication middleware
function authenticateAdmin(req, res, next) {
  const token = req.headers.authorization?.replace("Bearer ", "")
  const isAdmin = req.headers["x-admin-access"] === "true"

  if (!token || !isAdmin) {
    return res.status(401).json({ error: "Unauthorized" })
  }

  // In production, verify JWT token here
  next()
}

// MCQ Routes
app.get("/api/mcqs", async (req, res) => {
  try {
    const mcqs = await MCQ.find({ isActive: true }).sort({ createdAt: -1 })
    res.json(mcqs)
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
})

app.post("/api/mcqs", authenticateAdmin, async (req, res) => {
  try {
    const mcq = new MCQ(req.body)
    await mcq.save()

    // Broadcast to all clients
    broadcastToAll("mcq_created", mcq)

    res.status(201).json(mcq)
  } catch (error) {
    res.status(400).json({ error: error.message })
  }
})

app.put("/api/mcqs/:id", authenticateAdmin, async (req, res) => {
  try {
    const mcq = await MCQ.findByIdAndUpdate(req.params.id, { ...req.body, updatedAt: new Date() }, { new: true })

    if (!mcq) {
      return res.status(404).json({ error: "MCQ not found" })
    }

    // Broadcast to all clients
    broadcastToAll("mcq_updated", mcq)

    res.json(mcq)
  } catch (error) {
    res.status(400).json({ error: error.message })
  }
})

app.delete("/api/mcqs/:id", authenticateAdmin, async (req, res) => {
  try {
    const mcq = await MCQ.findByIdAndDelete(req.params.id)

    if (!mcq) {
      return res.status(404).json({ error: "MCQ not found" })
    }

    // Broadcast to all clients
    broadcastToAll("mcq_deleted", { id: req.params.id })

    res.json({ message: "MCQ deleted successfully" })
  } catch (error) {
    res.status(400).json({ error: error.message })
  }
})

// Bulk import MCQs
app.post("/api/mcqs/bulk-import", authenticateAdmin, upload.single("file"), async (req, res) => {
  try {
    const results = []
    const filePath = req.file.path

    fs.createReadStream(filePath)
      .pipe(csv())
      .on("data", (data) => results.push(data))
      .on("end", async () => {
        try {
          const mcqs = results.map((row) => ({
            question: row.question,
            options: [row.option1, row.option2, row.option3, row.option4],
            correctAnswer: Number.parseInt(row.correctAnswer),
            explanation: row.explanation,
            category: row.category,
            difficulty: row.difficulty,
            subject: row.subject,
            createdBy: "admin",
            isActive: true,
          }))

          const savedMCQs = await MCQ.insertMany(mcqs)

          // Broadcast to all clients
          broadcastToAll("mcqs_bulk_imported", { count: savedMCQs.length })

          // Clean up uploaded file
          fs.unlinkSync(filePath)

          res.json({ imported: savedMCQs, count: savedMCQs.length })
        } catch (error) {
          res.status(400).json({ error: error.message })
        }
      })
  } catch (error) {
    res.status(400).json({ error: error.message })
  }
})

// Exam Routes
app.get("/api/exams", async (req, res) => {
  try {
    const exams = await Exam.find({ isActive: true }).sort({ date: 1 })
    res.json(exams)
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
})

app.post("/api/exams", authenticateAdmin, async (req, res) => {
  try {
    const exam = new Exam(req.body)
    await exam.save()

    // Broadcast to all clients
    broadcastToAll("exam_created", exam)

    res.status(201).json(exam)
  } catch (error) {
    res.status(400).json({ error: error.message })
  }
})

app.put("/api/exams/:id", authenticateAdmin, async (req, res) => {
  try {
    const exam = await Exam.findByIdAndUpdate(req.params.id, { ...req.body, updatedAt: new Date() }, { new: true })

    if (!exam) {
      return res.status(404).json({ error: "Exam not found" })
    }

    // Broadcast to all clients
    broadcastToAll("exam_updated", exam)

    res.json(exam)
  } catch (error) {
    res.status(400).json({ error: error.message })
  }
})

app.delete("/api/exams/:id", authenticateAdmin, async (req, res) => {
  try {
    const exam = await Exam.findByIdAndDelete(req.params.id)

    if (!exam) {
      return res.status(404).json({ error: "Exam not found" })
    }

    // Broadcast to all clients
    broadcastToAll("exam_deleted", { id: req.params.id })

    res.json({ message: "Exam deleted successfully" })
  } catch (error) {
    res.status(400).json({ error: error.message })
  }
})

// Stats Route
app.get("/api/stats", async (req, res) => {
  try {
    const [totalMCQs, activeMCQs, totalExams, activeExams, totalUsers, activeUsers] = await Promise.all([
      MCQ.countDocuments(),
      MCQ.countDocuments({ isActive: true }),
      Exam.countDocuments(),
      Exam.countDocuments({ isActive: true }),
      User.countDocuments(),
      User.countDocuments({ isActive: true, lastActive: { $gte: new Date(Date.now() - 24 * 60 * 60 * 1000) } }),
    ])

    const today = new Date()
    today.setHours(0, 0, 0, 0)

    const testsToday = await TestSession.countDocuments({ createdAt: { $gte: today } })
    const avgScoreResult = await TestSession.aggregate([
      { $match: { createdAt: { $gte: today } } },
      { $group: { _id: null, avgScore: { $avg: "$score" } } },
    ])

    const avgScore = avgScoreResult.length > 0 ? Math.round(avgScoreResult[0].avgScore) : 0

    const stats = {
      totalMCQs,
      activeMCQs,
      totalExams,
      activeExams,
      totalUsers,
      activeUsers,
      testsToday,
      avgScore,
    }

    // Broadcast updated stats to admin clients
    broadcastToAdmins("stats_updated", stats)

    res.json(stats)
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
})

// Export data
app.get("/api/export", authenticateAdmin, async (req, res) => {
  try {
    const [mcqs, exams, users] = await Promise.all([MCQ.find(), Exam.find(), User.find()])

    const exportData = {
      mcqs,
      exams,
      users,
      exportedAt: new Date().toISOString(),
    }

    res.setHeader("Content-Type", "application/json")
    res.setHeader("Content-Disposition", "attachment; filename=kaamyaab-export.json")
    res.json(exportData)
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
})

// User Routes (for user app)
app.post("/api/users", async (req, res) => {
  try {
    const user = new User(req.body)
    await user.save()
    res.status(201).json(user)
  } catch (error) {
    res.status(400).json({ error: error.message })
  }
})

app.post("/api/test-sessions", async (req, res) => {
  try {
    const session = new TestSession(req.body)
    await session.save()

    // Broadcast test completion to admin clients
    broadcastToAdmins("test_completed", session)

    res.status(201).json(session)
  } catch (error) {
    res.status(400).json({ error: error.message })
  }
})

// Health check
app.get("/health", (req, res) => {
  res.json({ status: "OK", timestamp: new Date().toISOString() })
})

const PORT = process.env.PORT || 3001

server.listen(PORT, () => {
  console.log(`🚀 KaamYaab API Server running on port ${PORT}`)
  console.log(`📊 Admin WebSocket: ws://localhost:${PORT}/admin`)
  console.log(`👥 User WebSocket: ws://localhost:${PORT}/user`)
})
