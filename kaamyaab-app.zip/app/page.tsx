"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { SplashScreen } from "@/components/splash-screen"
import { motion, AnimatePresence } from "framer-motion"
import { BookOpen, Target, Trophy, Plus, Settings, Search, TrendingUp, Clock, Flame, Edit, Share2 } from "lucide-react"

// Simple Button Component
function Button({ children, onClick, className = "", variant = "default", size = "default", ...props }: any) {
  const baseClasses =
    "inline-flex items-center justify-center rounded-md font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:opacity-50 disabled:pointer-events-none ring-offset-background"

  const variants = {
    default: "bg-blue-600 text-white hover:bg-blue-700",
    outline: "border border-gray-300 bg-white hover:bg-gray-50",
    ghost: "hover:bg-gray-100",
  }

  const sizes = {
    default: "h-10 py-2 px-4",
    sm: "h-9 px-3 text-sm",
    lg: "h-11 px-8",
    icon: "h-10 w-10",
  }

  return (
    <button className={`${baseClasses} ${variants[variant]} ${sizes[size]} ${className}`} onClick={onClick} {...props}>
      {children}
    </button>
  )
}

// Simple Card Components
function Card({ children, className = "", ...props }: any) {
  return (
    <div className={`rounded-lg border bg-white shadow-sm ${className}`} {...props}>
      {children}
    </div>
  )
}

function CardHeader({ children, className = "", ...props }: any) {
  return (
    <div className={`flex flex-col space-y-1.5 p-6 ${className}`} {...props}>
      {children}
    </div>
  )
}

function CardTitle({ children, className = "", ...props }: any) {
  return (
    <h3 className={`text-2xl font-semibold leading-none tracking-tight ${className}`} {...props}>
      {children}
    </h3>
  )
}

function CardContent({ children, className = "", ...props }: any) {
  return (
    <div className={`p-6 pt-0 ${className}`} {...props}>
      {children}
    </div>
  )
}

// Simple Input Component
function Input({ className = "", ...props }: any) {
  return (
    <input
      className={`flex h-10 w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm ring-offset-white file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-gray-500 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 ${className}`}
      {...props}
    />
  )
}

// Simple Badge Component
function Badge({ children, className = "", variant = "default" }: any) {
  const variants = {
    default: "bg-blue-100 text-blue-800",
    secondary: "bg-gray-100 text-gray-800",
    outline: "border border-gray-300 text-gray-700",
  }

  return (
    <div
      className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold transition-colors ${variants[variant]} ${className}`}
    >
      {children}
    </div>
  )
}

// Simple Progress Component
function Progress({ value = 0, className = "" }: any) {
  return (
    <div className={`relative h-4 w-full overflow-hidden rounded-full bg-gray-200 ${className}`}>
      <div
        className="h-full bg-blue-600 transition-all duration-300 ease-in-out"
        style={{ width: `${Math.min(100, Math.max(0, value))}%` }}
      />
    </div>
  )
}

// Splash Screen Component
// function SplashScreen() {
//   return (
//     <div className="min-h-screen bg-gradient-to-br from-blue-600 via-purple-600 to-indigo-800 flex items-center justify-center relative overflow-hidden">
//       {/* Background Animation */}
//       <div className="absolute inset-0">
//         {[...Array(20)].map((_, i) => (
//           <motion.div
//             key={i}
//             className="absolute w-2 h-2 bg-white/20 rounded-full"
//             initial={{
//               x: Math.random() * (typeof window !== "undefined" ? window.innerWidth : 800),
//               y: Math.random() * (typeof window !== "undefined" ? window.innerHeight : 600),
//             }}
//             animate={{
//               y: [null, -100, (typeof window !== "undefined" ? window.innerHeight : 600) + 100],
//               opacity: [0, 1, 0],
//             }}
//             transition={{
//               duration: Math.random() * 3 + 2,
//               repeat: Number.POSITIVE_INFINITY,
//               delay: Math.random() * 2,
//             }}
//           />
//         ))}
//       </div>

//       <div className="text-center z-10">
//         {/* Logo Animation */}
//         <motion.div
//           initial={{ scale: 0, rotate: -180 }}
//           animate={{ scale: 1, rotate: 0 }}
//           transition={{
//             type: "spring",
//             stiffness: 200,
//             damping: 15,
//             duration: 1,
//           }}
//           className="relative mb-8"
//         >
//           <div className="w-32 h-32 mx-auto bg-white/20 backdrop-blur-sm rounded-3xl flex items-center justify-center shadow-2xl border border-white/30">
//             <GraduationCap className="w-16 h-16 text-white" />
//           </div>

//           {/* Floating Icons */}
//           <motion.div
//             animate={{
//               rotate: 360,
//               scale: [1, 1.1, 1],
//             }}
//             transition={{
//               rotate: { duration: 20, repeat: Number.POSITIVE_INFINITY, ease: "linear" },
//               scale: { duration: 2, repeat: Number.POSITIVE_INFINITY },
//             }}
//             className="absolute inset-0"
//           >
//             <BookOpen className="absolute -top-4 -left-4 w-8 h-8 text-white/60" />
//             <Target className="absolute -top-4 -right-4 w-8 h-8 text-white/60" />
//             <Trophy className="absolute -bottom-4 -left-4 w-8 h-8 text-white/60" />
//             <GraduationCap className="absolute -bottom-4 -right-4 w-8 h-8 text-white/60" />
//           </motion.div>
//         </motion.div>

//         {/* App Name */}
//         <motion.div
//           initial={{ opacity: 0, y: 20 }}
//           animate={{ opacity: 1, y: 0 }}
//           transition={{ delay: 0.5, duration: 0.8 }}
//           className="mb-4"
//         >
//           <h1 className="text-6xl font-bold text-white mb-2 tracking-tight">KaamYaab</h1>
//           <p className="text-xl text-white/80 font-medium">Your Success Partner</p>
//         </motion.div>

//         {/* Tagline */}
//         <motion.p
//           initial={{ opacity: 0, y: 20 }}
//           animate={{ opacity: 1, y: 0 }}
//           transition={{ delay: 0.8, duration: 0.8 }}
//           className="text-white/70 text-lg mb-8 max-w-md mx-auto"
//         >
//           Master competitive exams with AI-powered learning and comprehensive practice tests
//         </motion.p>

//         {/* Loading Animation */}
//         <motion.div
//           initial={{ opacity: 0 }}
//           animate={{ opacity: 1 }}
//           transition={{ delay: 1.2, duration: 0.5 }}
//           className="flex items-center justify-center space-x-2"
//         >
//           <div className="flex space-x-1">
//             {[...Array(3)].map((_, i) => (
//               <motion.div
//                 key={i}
//                 className="w-3 h-3 bg-white rounded-full"
//                 animate={{
//                   scale: [1, 1.5, 1],
//                   opacity: [0.5, 1, 0.5],
//                 }}
//                 transition={{
//                   duration: 1,
//                   repeat: Number.POSITIVE_INFINITY,
//                   delay: i * 0.2,
//                 }}
//               />
//             ))}
//           </div>
//           <span className="text-white/80 ml-4">Loading your success...</span>
//         </motion.div>

//         {/* Version */}
//         <motion.div
//           initial={{ opacity: 0 }}
//           animate={{ opacity: 1 }}
//           transition={{ delay: 2, duration: 0.5 }}
//           className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
//         >
//           <p className="text-white/50 text-sm">Version 2.0.0</p>
//         </motion.div>
//       </div>
//     </div>
//   )
// }

// Main Dashboard Component
function Dashboard() {
  const [searchQuery, setSearchQuery] = useState("")

  const tests = [
    {
      id: "1",
      name: "PPSC General Knowledge",
      progress: 75,
      category: "General Knowledge",
      color: "bg-blue-500",
      mcqCount: 150,
      lastStudied: "2 hours ago",
      difficulty: "Medium",
      averageScore: 78,
      bestScore: 92,
      attempts: 12,
    },
    {
      id: "2",
      name: "English Grammar & Composition",
      progress: 60,
      category: "English",
      color: "bg-green-500",
      mcqCount: 120,
      lastStudied: "1 day ago",
      difficulty: "Hard",
      averageScore: 65,
      bestScore: 85,
      attempts: 8,
    },
    {
      id: "3",
      name: "Pakistan Studies",
      progress: 85,
      category: "Pakistan Studies",
      color: "bg-purple-500",
      mcqCount: 200,
      lastStudied: "3 hours ago",
      difficulty: "Easy",
      averageScore: 82,
      bestScore: 95,
      attempts: 15,
    },
  ]

  const stats = [
    {
      title: "Study Streak",
      value: "7",
      unit: "days",
      icon: Flame,
      color: "from-orange-500 to-red-500",
    },
    {
      title: "Tests Completed",
      value: "89",
      unit: "tests",
      icon: Target,
      color: "from-green-500 to-emerald-500",
    },
    {
      title: "Average Score",
      value: "82",
      unit: "%",
      icon: TrendingUp,
      color: "from-blue-500 to-cyan-500",
    },
    {
      title: "Study Time",
      value: "24",
      unit: "hours",
      icon: Clock,
      color: "from-purple-500 to-pink-500",
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/90 backdrop-blur-xl border-b border-gray-200/50 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
                <BookOpen className="w-7 h-7 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600 bg-clip-text text-transparent">
                  KaamYaab
                </h1>
                <p className="text-xs text-gray-500 font-medium">Your Success Partner</p>
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <Button variant="ghost" size="icon">
                <Settings className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Search Bar */}
        <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} className="relative mb-8">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <Input
              placeholder="Search tests, subjects, or topics..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-12 h-14 text-lg bg-white/80 backdrop-blur-sm border-gray-200 focus:ring-2 focus:ring-blue-500 focus:border-transparent shadow-lg"
            />
          </div>
        </motion.div>

        {/* Stats Grid */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8"
        >
          {stats.map((stat, index) => {
            const Icon = stat.icon
            return (
              <Card key={stat.title} className="hover:shadow-lg transition-all duration-300">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600 mb-1">{stat.title}</p>
                      <div className="flex items-baseline space-x-1">
                        <span className="text-3xl font-bold text-gray-900">{stat.value}</span>
                        <span className="text-sm text-gray-500">{stat.unit}</span>
                      </div>
                    </div>
                    <div
                      className={`w-12 h-12 rounded-full bg-gradient-to-r ${stat.color} flex items-center justify-center`}
                    >
                      <Icon className="w-6 h-6 text-white" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </motion.div>

        {/* Test Cards Grid */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8"
        >
          {tests.map((test, index) => (
            <motion.div
              key={test.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ y: -4, scale: 1.02 }}
              className="group"
            >
              <Card className="relative overflow-hidden bg-white/80 backdrop-blur-sm hover:shadow-xl transition-all duration-500 cursor-pointer">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center space-x-2">
                      <div className={`w-4 h-4 rounded-full ${test.color}`} />
                      <Badge variant="outline" className="text-xs">
                        {test.difficulty}
                      </Badge>
                    </div>
                    <div className="flex space-x-1 opacity-0 group-hover:opacity-100 transition-all duration-300">
                      <Button variant="ghost" size="icon" className="w-8 h-8">
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button variant="ghost" size="icon" className="w-8 h-8">
                        <Share2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                  <CardTitle className="text-lg font-semibold group-hover:text-blue-600 transition-colors duration-300">
                    {test.name}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <Badge variant="secondary" className="text-xs">
                      {test.category}
                    </Badge>

                    <div className="space-y-3">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">Progress</span>
                        <span className="font-medium">{test.progress}%</span>
                      </div>
                      <Progress value={test.progress} className="h-2" />
                    </div>

                    <div className="grid grid-cols-2 gap-3 text-xs">
                      <div className="flex items-center space-x-1">
                        <Trophy className="w-3 h-3 text-yellow-500" />
                        <span className="text-gray-600">Best:</span>
                        <span className="font-medium">{test.bestScore}%</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Target className="w-3 h-3 text-blue-500" />
                        <span className="text-gray-600">Avg:</span>
                        <span className="font-medium">{test.averageScore}%</span>
                      </div>
                    </div>

                    <div className="flex justify-between text-xs text-gray-500 pt-2 border-t border-gray-200">
                      <span>{test.mcqCount} MCQs</span>
                      <span>{test.lastStudied}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>

        {/* Add Button */}
        <motion.div
          className="fixed bottom-6 right-6 z-40"
          initial={{ scale: 0, rotate: -180 }}
          animate={{ scale: 1, rotate: 0 }}
          transition={{ type: "spring", stiffness: 260, damping: 20, delay: 0.5 }}
        >
          <Button
            size="lg"
            className="w-16 h-16 rounded-full bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600 hover:from-blue-700 hover:via-purple-700 hover:to-indigo-700 shadow-2xl"
          >
            <Plus className="w-7 h-7" />
          </Button>
        </motion.div>
      </main>
    </div>
  )
}

// Main App Component
// export default function HomePage() {
//   const [isLoading, setIsLoading] = useState(true)

//   useEffect(() => {
//     const timer = setTimeout(() => {
//       setIsLoading(false)
//     }, 3000)

//     return () => clearTimeout(timer)
//   }, [])

//   return (
//     <div>
//       <AnimatePresence mode="wait">
//         {isLoading ? (
//           <motion.div key="splash" exit={{ opacity: 0, scale: 0.8 }} transition={{ duration: 0.5 }}>
//             <SplashScreen />
//           </motion.div>
//         ) : (
//           <motion.div
//             key="dashboard"
//             initial={{ opacity: 0, scale: 1.1 }}
//             animate={{ opacity: 1, scale: 1 }}
//             transition={{ duration: 0.5 }}
//           >
//             <Dashboard />
//           </motion.div>
//         )}
//       </AnimatePresence>
//     </div>
//   )
// }

export default function HomePage() {
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    const checkOnboarding = async () => {
      // Simulate loading time
      await new Promise((resolve) => setTimeout(resolve, 3000))

      const hasCompletedOnboarding = localStorage.getItem("kaamyaab_onboarding")

      if (hasCompletedOnboarding) {
        router.push("/dashboard")
      } else {
        router.push("/onboarding")
      }

      setIsLoading(false)
    }

    checkOnboarding()
  }, [router])

  return (
    <AnimatePresence mode="wait">
      {isLoading && (
        <motion.div key="splash" exit={{ opacity: 0, scale: 0.8 }} transition={{ duration: 0.5 }}>
          <SplashScreen />
        </motion.div>
      )}
    </AnimatePresence>
  )
}
