"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { motion, AnimatePresence } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { useAppContext } from "@/contexts/app-context"
import {
  GraduationCap,
  BookOpen,
  FileText,
  Globe,
  Languages,
  Clock,
  Users,
  Building,
  ArrowRight,
  CheckCircle,
} from "lucide-react"

const examCategories = [
  {
    id: "ppsc",
    name: "PPSC",
    fullName: "Punjab Public Service Commission",
    description: "Provincial civil service exams for Punjab",
    icon: Building,
    color: "from-blue-500 to-blue-600",
    subjects: ["General Knowledge", "Current Affairs", "Pakistan Studies", "English"],
  },
  {
    id: "fpsc",
    name: "FPSC",
    fullName: "Federal Public Service Commission",
    description: "Federal civil service competitive exams",
    icon: GraduationCap,
    color: "from-green-500 to-green-600",
    subjects: ["General Knowledge", "Current Affairs", "English", "Mathematics"],
  },
  {
    id: "css",
    name: "CSS",
    fullName: "Central Superior Services",
    description: "Elite civil service examination",
    icon: FileText,
    color: "from-purple-500 to-purple-600",
    subjects: ["Essay", "General Knowledge", "Current Affairs", "Pakistan Affairs"],
  },
  {
    id: "mpt",
    name: "MPT",
    fullName: "Military Police Training",
    description: "Military and police service exams",
    icon: Users,
    color: "from-red-500 to-red-600",
    subjects: ["General Knowledge", "Current Affairs", "Physical Training", "Law"],
  },
  {
    id: "gk",
    name: "General Knowledge",
    fullName: "General Knowledge Tests",
    description: "Comprehensive general knowledge preparation",
    icon: Globe,
    color: "from-orange-500 to-orange-600",
    subjects: ["World History", "Geography", "Science", "Current Events"],
  },
  {
    id: "english",
    name: "English",
    fullName: "English Language Tests",
    description: "English grammar, vocabulary and comprehension",
    icon: Languages,
    color: "from-teal-500 to-teal-600",
    subjects: ["Grammar", "Vocabulary", "Comprehension", "Writing"],
  },
  {
    id: "history",
    name: "History",
    fullName: "History & Pakistan Studies",
    description: "Historical knowledge and Pakistan studies",
    icon: Clock,
    color: "from-amber-500 to-amber-600",
    subjects: ["World History", "Pakistan History", "Islamic History", "Modern History"],
  },
  {
    id: "other",
    name: "Other Tests",
    fullName: "Miscellaneous Job Tests",
    description: "Various other competitive examinations",
    icon: BookOpen,
    color: "from-pink-500 to-pink-600",
    subjects: ["Banking", "Teaching", "Medical", "Engineering"],
  },
]

export default function OnboardingPage() {
  const [selectedCategories, setSelectedCategories] = useState<string[]>([])
  const [currentStep, setCurrentStep] = useState(0)
  const [userName, setUserName] = useState("")
  const router = useRouter()
  const { dispatch } = useAppContext()

  const handleCategoryToggle = (categoryId: string) => {
    setSelectedCategories((prev) =>
      prev.includes(categoryId) ? prev.filter((id) => id !== categoryId) : [...prev, categoryId],
    )
  }

  const handleComplete = () => {
    // Save user preferences
    const userPreferences = {
      name: userName,
      selectedCategories,
      completedAt: new Date().toISOString(),
    }

    localStorage.setItem("kaamyaab_onboarding", "completed")
    localStorage.setItem("kaamyaab_user_preferences", JSON.stringify(userPreferences))

    dispatch({ type: "SET_USER_PREFERENCES", payload: userPreferences })
    router.push("/dashboard")
  }

  const steps = [
    {
      title: "Welcome to KaamYaab! 🎉",
      subtitle: "Your ultimate companion for exam preparation",
      content: (
        <div className="space-y-6 text-center">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: "spring", stiffness: 200, damping: 15 }}
            className="w-32 h-32 mx-auto bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center shadow-2xl"
          >
            <GraduationCap className="w-16 h-16 text-white" />
          </motion.div>
          <div className="space-y-4">
            <h2 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              Ready to Succeed?
            </h2>
            <p className="text-gray-600 dark:text-gray-400 text-lg">
              Let's personalize your learning experience to help you achieve your goals
            </p>
          </div>
          <div className="space-y-2">
            <input
              type="text"
              placeholder="Enter your name"
              value={userName}
              onChange={(e) => setUserName(e.target.value)}
              className="w-full max-w-sm mx-auto px-4 py-3 rounded-xl border-2 border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 focus:border-blue-500 focus:outline-none transition-colors"
            />
          </div>
        </div>
      ),
    },
    {
      title: "Choose Your Path 🎯",
      subtitle: "Select the exams you want to prepare for",
      content: (
        <div className="space-y-6">
          <div className="text-center mb-8">
            <p className="text-gray-600 dark:text-gray-400">
              Select one or more categories that match your career goals
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-h-96 overflow-y-auto">
            {examCategories.map((category, index) => {
              const Icon = category.icon
              const isSelected = selectedCategories.includes(category.id)

              return (
                <motion.div
                  key={category.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <Card
                    className={`cursor-pointer transition-all duration-300 ${
                      isSelected
                        ? "ring-2 ring-blue-500 bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-700"
                        : "hover:shadow-lg border-gray-200 dark:border-gray-700"
                    }`}
                    onClick={() => handleCategoryToggle(category.id)}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-start space-x-4">
                        <div
                          className={`w-12 h-12 rounded-xl bg-gradient-to-r ${category.color} flex items-center justify-center flex-shrink-0`}
                        >
                          <Icon className="w-6 h-6 text-white" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between">
                            <h3 className="font-semibold text-lg">{category.name}</h3>
                            {isSelected && <CheckCircle className="w-5 h-5 text-blue-500" />}
                          </div>
                          <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">{category.fullName}</p>
                          <p className="text-xs text-gray-500 dark:text-gray-500 mb-3">{category.description}</p>
                          <div className="flex flex-wrap gap-1">
                            {category.subjects.slice(0, 3).map((subject) => (
                              <Badge key={subject} variant="secondary" className="text-xs">
                                {subject}
                              </Badge>
                            ))}
                            {category.subjects.length > 3 && (
                              <Badge variant="outline" className="text-xs">
                                +{category.subjects.length - 3}
                              </Badge>
                            )}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              )
            })}
          </div>
        </div>
      ),
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 dark:from-gray-950 dark:via-blue-950 dark:to-indigo-950 flex items-center justify-center p-4">
      <div className="w-full max-w-4xl">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentStep}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.3 }}
          >
            <Card className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-xl border-gray-200 dark:border-gray-700 shadow-2xl">
              <CardContent className="p-8">
                <div className="text-center mb-8">
                  <h1 className="text-2xl font-bold mb-2">{steps[currentStep].title}</h1>
                  <p className="text-gray-600 dark:text-gray-400">{steps[currentStep].subtitle}</p>
                </div>

                {steps[currentStep].content}

                <div className="flex justify-between items-center mt-8">
                  <div className="flex space-x-2">
                    {steps.map((_, index) => (
                      <div
                        key={index}
                        className={`w-3 h-3 rounded-full transition-colors ${
                          index === currentStep
                            ? "bg-blue-500"
                            : index < currentStep
                              ? "bg-green-500"
                              : "bg-gray-300 dark:bg-gray-600"
                        }`}
                      />
                    ))}
                  </div>

                  <div className="flex space-x-3">
                    {currentStep > 0 && (
                      <Button variant="outline" onClick={() => setCurrentStep(currentStep - 1)}>
                        Back
                      </Button>
                    )}

                    {currentStep < steps.length - 1 ? (
                      <Button
                        onClick={() => setCurrentStep(currentStep + 1)}
                        disabled={currentStep === 0 && !userName.trim()}
                        className="flex items-center space-x-2"
                      >
                        <span>Next</span>
                        <ArrowRight className="w-4 h-4" />
                      </Button>
                    ) : (
                      <Button
                        onClick={handleComplete}
                        disabled={selectedCategories.length === 0}
                        className="flex items-center space-x-2 bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700"
                      >
                        <span>Get Started</span>
                        <ArrowRight className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  )
}
