"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { motion } from "framer-motion"
import {
  BookOpen,
  Calendar,
  Clock,
  TrendingUp,
  Trophy,
  Flame,
  Target,
  Settings,
  Bell,
  Search,
  Plus,
  BarChart3,
  Play,
  History,
  Shuffle,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { useAppContext } from "@/contexts/app-context"
import { MaterialCard } from "@/components/material-card"
import { ThemeToggle } from "@/components/theme-toggle"
import { AnalyticsDialog } from "@/components/analytics-dialog"
import { AchievementsDialog } from "@/components/achievements-dialog"
import { SettingsDialog } from "@/components/settings-dialog"

export default function DashboardPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [userStats, setUserStats] = useState({
    studyStreak: 0,
    testsCompleted: 0,
    averageScore: 0,
    totalStudyTime: 0,
  })
  const [examCategories, setExamCategories] = useState<any[]>([])
  const [showAnalytics, setShowAnalytics] = useState(false)
  const [showAchievements, setShowAchievements] = useState(false)
  const [showSettings, setShowSettings] = useState(false)
  const { state } = useAppContext()
  const router = useRouter()

  useEffect(() => {
    loadUserData()
  }, [])

  const loadUserData = () => {
    const userPreferences = JSON.parse(localStorage.getItem("kaamyaab_user_preferences") || "{}")
    const testSessions = JSON.parse(localStorage.getItem("kaamyaab_test_sessions") || "[]")

    // Calculate stats from actual test sessions
    const stats = calculateUserStats(testSessions)
    setUserStats(stats)

    // Load categories with actual progress
    const categories = loadCategoriesWithProgress(userPreferences.selectedCategories || [], testSessions)
    setExamCategories(categories)
  }

  const calculateUserStats = (testSessions: any[]) => {
    if (testSessions.length === 0) {
      return {
        studyStreak: 0,
        testsCompleted: 0,
        averageScore: 0,
        totalStudyTime: 0,
      }
    }

    const totalScore = testSessions.reduce((sum, session) => sum + (session.score || 0), 0)
    const totalTime = testSessions.reduce((sum, session) => sum + (session.timeSpent || 0), 0)

    // Calculate study streak (consecutive days with tests)
    const studyStreak = calculateStudyStreak(testSessions)

    return {
      studyStreak,
      testsCompleted: testSessions.length,
      averageScore: Math.round(totalScore / testSessions.length),
      totalStudyTime: Math.round(totalTime / 60), // Convert to hours
    }
  }

  const calculateStudyStreak = (testSessions: any[]) => {
    if (testSessions.length === 0) return 0

    const sortedSessions = testSessions.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    const today = new Date()
    let streak = 0
    const currentDate = new Date(today)

    for (let i = 0; i < 30; i++) {
      // Check last 30 days
      const dateStr = currentDate.toISOString().split("T")[0]
      const hasTestOnDate = sortedSessions.some((session) => session.date.split("T")[0] === dateStr)

      if (hasTestOnDate) {
        streak++
      } else if (streak > 0) {
        break // Streak broken
      }

      currentDate.setDate(currentDate.getDate() - 1)
    }

    return streak
  }

  const loadCategoriesWithProgress = (selectedCategories: string[], testSessions: any[]) => {
    const categoryMap = {
      ppsc: {
        id: "ppsc",
        name: "PPSC",
        fullName: "Punjab Public Service Commission",
        icon: "🏛️",
        color: "from-blue-500 to-blue-600",
      },
      fpsc: {
        id: "fpsc",
        name: "FPSC",
        fullName: "Federal Public Service Commission",
        icon: "🎓",
        color: "from-green-500 to-green-600",
      },
      css: {
        id: "css",
        name: "CSS",
        fullName: "Central Superior Services",
        icon: "📜",
        color: "from-purple-500 to-purple-600",
      },
      mpt: {
        id: "mpt",
        name: "MPT",
        fullName: "Military Police Training",
        icon: "🛡️",
        color: "from-red-500 to-red-600",
      },
      gk: {
        id: "gk",
        name: "General Knowledge",
        fullName: "General Knowledge Tests",
        icon: "🌍",
        color: "from-orange-500 to-orange-600",
      },
      english: {
        id: "english",
        name: "English",
        fullName: "English Language Tests",
        icon: "📚",
        color: "from-teal-500 to-teal-600",
      },
    }

    return selectedCategories
      .map((categoryId) => {
        const category = categoryMap[categoryId as keyof typeof categoryMap]
        if (!category) return null

        const categorySessions = testSessions.filter((session) => session.category === categoryId)
        const totalTests = 100 // Assume 100 total tests per category
        const completedTests = categorySessions.length
        const progress = Math.min((completedTests / totalTests) * 100, 100)
        const lastScore = categorySessions.length > 0 ? categorySessions[categorySessions.length - 1].score : 0
        const upcomingExams = Math.floor(Math.random() * 3) + 1 // Mock data

        return {
          ...category,
          progress: Math.round(progress),
          totalTests,
          completedTests,
          upcomingExams,
          lastScore: Math.round(lastScore),
        }
      })
      .filter(Boolean)
  }

  const handleCategorySelect = (categoryId: string) => {
    router.push(`/test/${categoryId}`)
  }

  const userName = JSON.parse(localStorage.getItem("kaamyaab_user_preferences") || "{}").name || "Student"

  const stats = [
    {
      title: "Study Streak",
      value: userStats.studyStreak.toString(),
      unit: "days",
      icon: Flame,
      color: "from-orange-500 to-red-500",
      change: "+2 from last week",
    },
    {
      title: "Tests Completed",
      value: userStats.testsCompleted.toString(),
      unit: "tests",
      icon: Target,
      color: "from-green-500 to-emerald-500",
      change: "+12 this week",
    },
    {
      title: "Average Score",
      value: userStats.averageScore.toString(),
      unit: "%",
      icon: TrendingUp,
      color: "from-blue-500 to-cyan-500",
      change: "+5% improvement",
    },
    {
      title: "Study Time",
      value: userStats.totalStudyTime.toString(),
      unit: "hours",
      icon: Clock,
      color: "from-purple-500 to-pink-500",
      change: "This week",
    },
  ]

  // Mock achievements data
  const achievements = [
    {
      id: "1",
      title: "First Steps",
      description: "Complete your first test",
      icon: "🎯",
      unlocked: userStats.testsCompleted > 0,
      progress: Math.min(userStats.testsCompleted, 1),
      maxProgress: 1,
      category: "study" as const,
    },
    {
      id: "2",
      title: "Study Streak",
      description: "Study for 7 consecutive days",
      icon: "🔥",
      unlocked: userStats.studyStreak >= 7,
      progress: Math.min(userStats.studyStreak, 7),
      maxProgress: 7,
      category: "streak" as const,
    },
    {
      id: "3",
      title: "High Achiever",
      description: "Score above 90% in any test",
      icon: "⭐",
      unlocked: userStats.averageScore >= 90,
      progress: Math.min(userStats.averageScore, 90),
      maxProgress: 90,
      category: "score" as const,
    },
  ]

  // Mock progress data for analytics
  const progressData = [
    { date: "2024-01-01", score: 65, timeSpent: 30, accuracy: 70 },
    { date: "2024-01-02", score: 72, timeSpent: 35, accuracy: 75 },
    { date: "2024-01-03", score: 78, timeSpent: 40, accuracy: 80 },
    { date: "2024-01-04", score: 85, timeSpent: 45, accuracy: 85 },
    { date: "2024-01-05", score: 82, timeSpent: 50, accuracy: 83 },
  ]

  const upcomingExams = [
    {
      id: 1,
      title: "PPSC Lecturer (Education) Test",
      date: "2024-01-15",
      time: "10:00 AM",
      location: "Lahore",
      category: "PPSC",
      daysLeft: 12,
    },
    {
      id: 2,
      title: "FPSC Assistant Director Test",
      date: "2024-01-22",
      time: "2:00 PM",
      location: "Islamabad",
      category: "FPSC",
      daysLeft: 19,
    },
    {
      id: 3,
      title: "CSS Written Examination",
      date: "2024-02-10",
      time: "9:00 AM",
      location: "Multiple Cities",
      category: "CSS",
      daysLeft: 38,
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 dark:from-gray-950 dark:via-blue-950 dark:to-indigo-950">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/90 dark:bg-gray-900/90 backdrop-blur-xl border-b border-gray-200/50 dark:border-gray-700/50 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <motion.div whileHover={{ scale: 1.05 }} className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
                  <BookOpen className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h1 className="text-xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                    KaamYaab
                  </h1>
                  <p className="text-xs text-gray-500 dark:text-gray-400">Welcome back, {userName}!</p>
                </div>
              </motion.div>
            </div>

            <div className="flex items-center space-x-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Search tests..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 w-64 bg-white/50 dark:bg-gray-800/50 backdrop-blur-sm"
                />
              </div>

              <Button variant="ghost" size="icon" className="relative">
                <Bell className="w-5 h-5" />
                {userStats.testsCompleted > 0 && (
                  <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full animate-pulse" />
                )}
              </Button>

              <ThemeToggle />

              <Button variant="ghost" size="icon" onClick={() => setShowSettings(true)}>
                <Settings className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">Good morning, {userName}! 🌅</h2>
              <p className="text-gray-600 dark:text-gray-400">
                Ready to continue your learning journey? You're doing great!
              </p>
            </div>
            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Button
                className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700"
                onClick={() => router.push("/practice")}
              >
                <Plus className="w-4 h-4 mr-2" />
                Start New Test
              </Button>
            </motion.div>
          </div>
        </motion.div>

        {/* Stats Grid */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8"
        >
          {stats.map((stat, index) => {
            const Icon = stat.icon
            return (
              <MaterialCard key={stat.title} delay={index * 0.1}>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">{stat.title}</p>
                      <div className="flex items-baseline space-x-1">
                        <span className="text-3xl font-bold text-gray-900 dark:text-white">{stat.value}</span>
                        <span className="text-sm text-gray-500 dark:text-gray-400">{stat.unit}</span>
                      </div>
                      <p className="text-xs text-green-600 dark:text-green-400 mt-1">{stat.change}</p>
                    </div>
                    <div
                      className={`w-12 h-12 rounded-xl bg-gradient-to-r ${stat.color} flex items-center justify-center shadow-lg`}
                    >
                      <Icon className="w-6 h-6 text-white" />
                    </div>
                  </div>
                </CardContent>
              </MaterialCard>
            )
          })}
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Exam Categories */}
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white">Your Exam Categories</h3>
                <Button variant="outline" size="sm" onClick={() => setShowAnalytics(true)}>
                  <BarChart3 className="w-4 h-4 mr-2" />
                  View Analytics
                </Button>
              </div>

              {examCategories.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {examCategories.map((category, index) => (
                    <MaterialCard key={category.id} delay={0.3 + index * 0.1}>
                      <CardContent className="p-6">
                        <div className="flex items-start justify-between mb-4">
                          <div className="flex items-center space-x-3">
                            <div className="text-2xl">{category.icon}</div>
                            <div>
                              <h4 className="font-semibold text-lg text-gray-900 dark:text-white">{category.name}</h4>
                              <p className="text-sm text-gray-600 dark:text-gray-400">{category.fullName}</p>
                            </div>
                          </div>
                          <Badge variant="secondary" className="text-xs">
                            {category.progress}%
                          </Badge>
                        </div>

                        <div className="space-y-4">
                          <div>
                            <div className="flex justify-between text-sm mb-2">
                              <span className="text-gray-600 dark:text-gray-400">Progress</span>
                              <span className="font-medium">
                                {category.completedTests}/{category.totalTests} tests
                              </span>
                            </div>
                            <Progress value={category.progress} className="h-2" />
                          </div>

                          <div className="grid grid-cols-3 gap-4 text-center">
                            <div>
                              <div className="text-lg font-bold text-blue-600">{category.lastScore}%</div>
                              <div className="text-xs text-gray-500">Last Score</div>
                            </div>
                            <div>
                              <div className="text-lg font-bold text-green-600">{category.completedTests}</div>
                              <div className="text-xs text-gray-500">Completed</div>
                            </div>
                            <div>
                              <div className="text-lg font-bold text-orange-600">{category.upcomingExams}</div>
                              <div className="text-xs text-gray-500">Upcoming</div>
                            </div>
                          </div>

                          <div className="flex space-x-2 pt-2">
                            <Button size="sm" className="flex-1" onClick={() => handleCategorySelect(category.id)}>
                              <Play className="w-4 h-4 mr-2" />
                              Continue
                            </Button>
                            <Button variant="outline" size="sm" onClick={() => setShowAnalytics(true)}>
                              <BarChart3 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </MaterialCard>
                  ))}
                </div>
              ) : (
                <MaterialCard>
                  <CardContent className="p-8 text-center">
                    <BookOpen className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                    <h4 className="text-lg font-semibold mb-2">No categories selected</h4>
                    <p className="text-gray-600 dark:text-gray-400 mb-4">
                      Add some exam categories to start your preparation journey
                    </p>
                    <Button onClick={() => router.push("/onboarding")}>
                      <Plus className="w-4 h-4 mr-2" />
                      Add Categories
                    </Button>
                  </CardContent>
                </MaterialCard>
              )}
            </motion.div>

            {/* Quick Actions */}
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
              <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">Quick Actions</h3>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <MaterialCard>
                  <CardContent className="p-6 text-center">
                    <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-blue-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                      <Shuffle className="w-6 h-6 text-white" />
                    </div>
                    <h4 className="font-semibold mb-2">Random Test</h4>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                      Take a mixed quiz from all categories
                    </p>
                    <Button size="sm" variant="outline" className="w-full" onClick={() => router.push("/practice")}>
                      Start Random Test
                    </Button>
                  </CardContent>
                </MaterialCard>

                <MaterialCard>
                  <CardContent className="p-6 text-center">
                    <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-green-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                      <History className="w-6 h-6 text-white" />
                    </div>
                    <h4 className="font-semibold mb-2">Past Papers</h4>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">Practice with previous exam papers</p>
                    <Button size="sm" variant="outline" className="w-full">
                      Browse Papers
                    </Button>
                  </CardContent>
                </MaterialCard>

                <MaterialCard>
                  <CardContent className="p-6 text-center">
                    <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-purple-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                      <Trophy className="w-6 h-6 text-white" />
                    </div>
                    <h4 className="font-semibold mb-2">Achievements</h4>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">View your progress and badges</p>
                    <Button size="sm" variant="outline" className="w-full" onClick={() => setShowAchievements(true)}>
                      View Achievements
                    </Button>
                  </CardContent>
                </MaterialCard>
              </div>
            </motion.div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Upcoming Exams */}
            <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.3 }}>
              <MaterialCard>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Calendar className="w-5 h-5 text-blue-600" />
                    <span>Upcoming Exams</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {upcomingExams.slice(0, 3).map((exam) => (
                    <div
                      key={exam.id}
                      className="flex items-start space-x-3 p-3 rounded-lg bg-gray-50 dark:bg-gray-800/50"
                    >
                      <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0" />
                      <div className="flex-1 min-w-0">
                        <h4 className="font-medium text-sm line-clamp-2">{exam.title}</h4>
                        <div className="flex items-center space-x-2 mt-1">
                          <Badge variant="outline" className="text-xs">
                            {exam.category}
                          </Badge>
                          <span className="text-xs text-gray-500">{exam.daysLeft} days left</span>
                        </div>
                        <p className="text-xs text-gray-600 dark:text-gray-400 mt-1">
                          {exam.date} • {exam.time}
                        </p>
                      </div>
                    </div>
                  ))}
                  <Button variant="outline" size="sm" className="w-full">
                    View All Exams
                  </Button>
                </CardContent>
              </MaterialCard>
            </motion.div>

            {/* Recent Activity */}
            <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.4 }}>
              <MaterialCard>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Clock className="w-5 h-5 text-green-600" />
                    <span>Recent Activity</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {userStats.testsCompleted > 0 ? (
                    [
                      { action: "Completed practice test", score: `${userStats.averageScore}%`, time: "Recently" },
                      { action: `${userStats.studyStreak} day study streak`, score: "🔥", time: "Ongoing" },
                      { action: "Studied for the first time", score: "🎯", time: "This week" },
                    ]
                      .slice(0, userStats.testsCompleted)
                      .map((activity, index) => (
                        <div key={index} className="flex items-center space-x-3 text-sm">
                          <div className="w-2 h-2 bg-green-500 rounded-full flex-shrink-0" />
                          <div className="flex-1 min-w-0">
                            <p className="font-medium line-clamp-1">{activity.action}</p>
                            <div className="flex items-center space-x-2 text-xs text-gray-500">
                              <span>{activity.score}</span>
                              <span>•</span>
                              <span>{activity.time}</span>
                            </div>
                          </div>
                        </div>
                      ))
                  ) : (
                    <div className="text-center py-4">
                      <BookOpen className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                      <p className="text-sm text-gray-500">No activity yet</p>
                      <p className="text-xs text-gray-400">Start a test to see your progress here</p>
                    </div>
                  )}
                </CardContent>
              </MaterialCard>
            </motion.div>
          </div>
        </div>
      </main>

      {/* Dialogs */}
      <AnalyticsDialog
        open={showAnalytics}
        onOpenChange={setShowAnalytics}
        tests={examCategories}
        progressData={progressData}
      />

      <AchievementsDialog open={showAchievements} onOpenChange={setShowAchievements} achievements={achievements} />

      <SettingsDialog open={showSettings} onOpenChange={setShowSettings} />
    </div>
  )
}
