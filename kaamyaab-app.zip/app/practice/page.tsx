"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { motion } from "framer-motion"
import { ArrowLeft, Play, Shuffle, BookOpen, Target, Clock, Users } from "lucide-react"
import { Button } from "@/components/ui/button"
import { CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { MaterialCard } from "@/components/material-card"
import { MCQDialog } from "@/components/mcq-dialog"

const categories = [
  { id: "all", name: "All Categories", icon: "🎯" },
  { id: "ppsc", name: "PPSC", icon: "🏛️" },
  { id: "fpsc", name: "FPSC", icon: "🎓" },
  { id: "css", name: "CSS", icon: "📜" },
  { id: "gk", name: "General Knowledge", icon: "🌍" },
  { id: "english", name: "English", icon: "📚" },
  { id: "history", name: "History", icon: "🕰️" },
]

const difficulties = [
  { id: "all", name: "All Levels" },
  { id: "easy", name: "Easy" },
  { id: "medium", name: "Medium" },
  { id: "hard", name: "Hard" },
]

export default function PracticePage() {
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [selectedDifficulty, setSelectedDifficulty] = useState("all")
  const [questionCount, setQuestionCount] = useState("10")
  const [showMCQDialog, setShowMCQDialog] = useState(false)
  const [testData, setTestData] = useState(null)
  const router = useRouter()

  const createTest = () => {
    const test = {
      id: Date.now().toString(),
      name: `Practice Test - ${categories.find((c) => c.id === selectedCategory)?.name || "Mixed"}`,
      category: selectedCategory,
      difficulty: selectedDifficulty === "all" ? "Medium" : selectedDifficulty,
      mcqCount: Number.parseInt(questionCount),
      progress: 0,
      lastStudied: "Now",
      color: "bg-blue-500",
      averageScore: 0,
      timeSpent: 0,
      streak: 0,
      bestScore: 0,
      attempts: 0,
    }

    setTestData(test)
    setShowMCQDialog(true)
  }

  const handleScoreUpdate = (score: number, timeSpent: number) => {
    // Save test session to localStorage
    const testSession = {
      id: Date.now().toString(),
      category: selectedCategory,
      score,
      timeSpent,
      date: new Date().toISOString(),
      difficulty: selectedDifficulty === "all" ? "Medium" : selectedDifficulty,
      questionCount: Number.parseInt(questionCount),
    }

    const existingSessions = JSON.parse(localStorage.getItem("kaamyaab_test_sessions") || "[]")
    existingSessions.push(testSession)
    localStorage.setItem("kaamyaab_test_sessions", JSON.stringify(existingSessions))

    // Redirect to dashboard
    router.push("/dashboard")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 dark:from-gray-950 dark:via-blue-950 dark:to-indigo-950">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/90 dark:bg-gray-900/90 backdrop-blur-xl border-b border-gray-200/50 dark:border-gray-700/50 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="icon" onClick={() => router.push("/dashboard")}>
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-gradient-to-r from-green-500 to-blue-500 rounded-xl flex items-center justify-center shadow-lg">
                  <Play className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-gray-900 dark:text-white">Practice Tests</h1>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Choose your test configuration</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Test Configuration */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
          <MaterialCard>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Target className="w-6 h-6 text-blue-600" />
                <span>Configure Your Test</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-700 dark:text-gray-300">Category</label>
                  <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map((category) => (
                        <SelectItem key={category.id} value={category.id}>
                          <div className="flex items-center space-x-2">
                            <span>{category.icon}</span>
                            <span>{category.name}</span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-700 dark:text-gray-300">Difficulty</label>
                  <Select value={selectedDifficulty} onValueChange={setSelectedDifficulty}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {difficulties.map((difficulty) => (
                        <SelectItem key={difficulty.id} value={difficulty.id}>
                          {difficulty.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-700 dark:text-gray-300">Questions</label>
                  <Select value={questionCount} onValueChange={setQuestionCount}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="5">5 Questions</SelectItem>
                      <SelectItem value="10">10 Questions</SelectItem>
                      <SelectItem value="15">15 Questions</SelectItem>
                      <SelectItem value="20">20 Questions</SelectItem>
                      <SelectItem value="25">25 Questions</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="flex items-center justify-between pt-4 border-t border-gray-200 dark:border-gray-700">
                <div className="flex items-center space-x-4 text-sm text-gray-600 dark:text-gray-400">
                  <div className="flex items-center space-x-1">
                    <Clock className="w-4 h-4" />
                    <span>~{Number.parseInt(questionCount) * 1.5} minutes</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Users className="w-4 h-4" />
                    <span>Practice Mode</span>
                  </div>
                </div>

                <Button onClick={createTest} className="bg-gradient-to-r from-green-500 to-blue-500">
                  <Play className="w-4 h-4 mr-2" />
                  Start Test
                </Button>
              </div>
            </CardContent>
          </MaterialCard>
        </motion.div>

        {/* Quick Start Options */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
          <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">Quick Start</h3>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                title: "Quick Practice",
                description: "5 random questions from all categories",
                icon: Shuffle,
                color: "from-blue-500 to-blue-600",
                config: { category: "all", difficulty: "all", questions: "5" },
              },
              {
                title: "Standard Test",
                description: "15 questions from your selected categories",
                icon: Target,
                color: "from-green-500 to-green-600",
                config: { category: "all", difficulty: "medium", questions: "15" },
              },
              {
                title: "Challenge Mode",
                description: "20 hard questions to test your limits",
                icon: BookOpen,
                color: "from-purple-500 to-purple-600",
                config: { category: "all", difficulty: "hard", questions: "20" },
              },
            ].map((option, index) => {
              const Icon = option.icon
              return (
                <MaterialCard key={option.title} delay={index * 0.1}>
                  <CardContent className="p-6">
                    <div className="text-center space-y-4">
                      <div
                        className={`w-16 h-16 mx-auto bg-gradient-to-r ${option.color} rounded-full flex items-center justify-center`}
                      >
                        <Icon className="w-8 h-8 text-white" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-lg text-gray-900 dark:text-white">{option.title}</h4>
                        <p className="text-sm text-gray-600 dark:text-gray-400 mt-2">{option.description}</p>
                      </div>
                      <Button
                        variant="outline"
                        className="w-full"
                        onClick={() => {
                          setSelectedCategory(option.config.category)
                          setSelectedDifficulty(option.config.difficulty)
                          setQuestionCount(option.config.questions)
                          setTimeout(createTest, 100)
                        }}
                      >
                        Start Now
                      </Button>
                    </div>
                  </CardContent>
                </MaterialCard>
              )
            })}
          </div>
        </motion.div>

        {/* Study Tips */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mt-8"
        >
          <MaterialCard>
            <CardContent className="p-6">
              <h4 className="font-semibold text-lg mb-4">📚 Study Tips</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-gray-600 dark:text-gray-400">
                <div className="space-y-2">
                  <p>• Take breaks between long study sessions</p>
                  <p>• Review incorrect answers carefully</p>
                  <p>• Practice regularly to build consistency</p>
                </div>
                <div className="space-y-2">
                  <p>• Focus on your weak subjects first</p>
                  <p>• Time yourself to improve speed</p>
                  <p>• Keep track of your progress</p>
                </div>
              </div>
            </CardContent>
          </MaterialCard>
        </motion.div>
      </main>

      {/* MCQ Dialog */}
      <MCQDialog
        open={showMCQDialog}
        onOpenChange={setShowMCQDialog}
        test={testData}
        onScoreUpdate={handleScoreUpdate}
      />
    </div>
  )
}
