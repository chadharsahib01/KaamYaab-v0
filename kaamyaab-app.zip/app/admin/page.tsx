"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import {
  Plus,
  Edit,
  Trash2,
  Save,
  Upload,
  Download,
  BookOpen,
  Calendar,
  BarChart3,
  Settings,
  Target,
  Search,
  Eye,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { MaterialCard } from "@/components/material-card"
import { Switch } from "@/components/ui/switch"

interface MCQ {
  id: string
  question: string
  options: string[]
  correctAnswer: number
  explanation: string
  category: string
  difficulty: "Easy" | "Medium" | "Hard"
  subject: string
  createdAt: string
  isActive: boolean
}

interface UpcomingExam {
  id: string
  title: string
  date: string
  time: string
  location: string
  category: string
  applicationDeadline: string
  fee: string
  posts: number
  description: string
  isActive: boolean
}

const initialMCQs: MCQ[] = [
  {
    id: "1",
    question: "What is the capital of Pakistan?",
    options: ["Karachi", "Lahore", "Islamabad", "Peshawar"],
    correctAnswer: 2,
    explanation: "Islamabad is the capital city of Pakistan, established in 1960 as a planned city.",
    category: "PPSC",
    difficulty: "Easy",
    subject: "General Knowledge",
    createdAt: "2024-01-01",
    isActive: true,
  },
  {
    id: "2",
    question: "Who was the founder of Pakistan?",
    options: ["Allama Iqbal", "Quaid-e-Azam Muhammad Ali Jinnah", "Liaquat Ali Khan", "Sir Syed Ahmad Khan"],
    correctAnswer: 1,
    explanation: "Quaid-e-Azam Muhammad Ali Jinnah is known as the founder of Pakistan and led the Pakistan movement.",
    category: "PPSC",
    difficulty: "Easy",
    subject: "Pakistan Studies",
    createdAt: "2024-01-01",
    isActive: true,
  },
  {
    id: "3",
    question: "In which year did Pakistan become an Islamic Republic?",
    options: ["1947", "1956", "1973", "1962"],
    correctAnswer: 1,
    explanation: "Pakistan became an Islamic Republic in 1956 with the adoption of its first constitution.",
    category: "CSS",
    difficulty: "Medium",
    subject: "Pakistan Studies",
    createdAt: "2024-01-01",
    isActive: true,
  },
]

const initialExams: UpcomingExam[] = [
  {
    id: "1",
    title: "PPSC Lecturer (Education) - BPS-17",
    date: "2024-01-15",
    time: "10:00 AM",
    location: "Lahore, Faisalabad, Multan",
    category: "PPSC",
    applicationDeadline: "2024-01-05",
    fee: "Rs. 500",
    posts: 45,
    description: "Recruitment for Lecturer positions in Education Department",
    isActive: true,
  },
  {
    id: "2",
    title: "FPSC Assistant Director - BPS-17",
    date: "2024-01-22",
    time: "2:00 PM",
    location: "Islamabad, Karachi",
    category: "FPSC",
    applicationDeadline: "2024-01-10",
    fee: "Rs. 600",
    posts: 12,
    description: "Federal recruitment for Assistant Director positions",
    isActive: true,
  },
]

export default function AdminPage() {
  const [mcqs, setMCQs] = useState<MCQ[]>(initialMCQs)
  const [exams, setExams] = useState<UpcomingExam[]>(initialExams)
  const [activeTab, setActiveTab] = useState("dashboard")
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [isAddMCQOpen, setIsAddMCQOpen] = useState(false)
  const [isAddExamOpen, setIsAddExamOpen] = useState(false)
  const [editingMCQ, setEditingMCQ] = useState<MCQ | null>(null)
  const [editingExam, setEditingExam] = useState<UpcomingExam | null>(null)

  const [newMCQ, setNewMCQ] = useState<Partial<MCQ>>({
    question: "",
    options: ["", "", "", ""],
    correctAnswer: 0,
    explanation: "",
    category: "PPSC",
    difficulty: "Easy",
    subject: "",
    isActive: true,
  })

  const [newExam, setNewExam] = useState<Partial<UpcomingExam>>({
    title: "",
    date: "",
    time: "",
    location: "",
    category: "PPSC",
    applicationDeadline: "",
    fee: "",
    posts: 0,
    description: "",
    isActive: true,
  })

  const handleAddMCQ = () => {
    if (newMCQ.question && newMCQ.options?.every((opt) => opt.trim()) && newMCQ.explanation) {
      const mcq: MCQ = {
        id: Date.now().toString(),
        question: newMCQ.question,
        options: newMCQ.options as string[],
        correctAnswer: newMCQ.correctAnswer || 0,
        explanation: newMCQ.explanation,
        category: newMCQ.category || "PPSC",
        difficulty: newMCQ.difficulty || "Easy",
        subject: newMCQ.subject || "",
        createdAt: new Date().toISOString().split("T")[0],
        isActive: newMCQ.isActive || true,
      }
      setMCQs([...mcqs, mcq])
      setNewMCQ({
        question: "",
        options: ["", "", "", ""],
        correctAnswer: 0,
        explanation: "",
        category: "PPSC",
        difficulty: "Easy",
        subject: "",
        isActive: true,
      })
      setIsAddMCQOpen(false)
    }
  }

  const handleAddExam = () => {
    if (newExam.title && newExam.date && newExam.time) {
      const exam: UpcomingExam = {
        id: Date.now().toString(),
        title: newExam.title,
        date: newExam.date,
        time: newExam.time,
        location: newExam.location || "",
        category: newExam.category || "PPSC",
        applicationDeadline: newExam.applicationDeadline || "",
        fee: newExam.fee || "",
        posts: newExam.posts || 0,
        description: newExam.description || "",
        isActive: newExam.isActive || true,
      }
      setExams([...exams, exam])
      setNewExam({
        title: "",
        date: "",
        time: "",
        location: "",
        category: "PPSC",
        applicationDeadline: "",
        fee: "",
        posts: 0,
        description: "",
        isActive: true,
      })
      setIsAddExamOpen(false)
    }
  }

  const handleDeleteMCQ = (id: string) => {
    setMCQs(mcqs.filter((mcq) => mcq.id !== id))
  }

  const handleDeleteExam = (id: string) => {
    setExams(exams.filter((exam) => exam.id !== id))
  }

  const handleToggleMCQStatus = (id: string) => {
    setMCQs(mcqs.map((mcq) => (mcq.id === id ? { ...mcq, isActive: !mcq.isActive } : mcq)))
  }

  const handleToggleExamStatus = (id: string) => {
    setExams(exams.map((exam) => (exam.id === id ? { ...exam, isActive: !exam.isActive } : exam)))
  }

  const filteredMCQs = mcqs.filter((mcq) => {
    const matchesSearch =
      mcq.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
      mcq.subject.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesCategory = selectedCategory === "all" || mcq.category === selectedCategory
    return matchesSearch && matchesCategory
  })

  const stats = {
    totalMCQs: mcqs.length,
    activeMCQs: mcqs.filter((mcq) => mcq.isActive).length,
    totalExams: exams.length,
    activeExams: exams.filter((exam) => exam.isActive).length,
    categories: [...new Set(mcqs.map((mcq) => mcq.category))].length,
    subjects: [...new Set(mcqs.map((mcq) => mcq.subject))].length,
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 dark:from-gray-950 dark:via-blue-950 dark:to-indigo-950">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/90 dark:bg-gray-900/90 backdrop-blur-xl border-b border-gray-200/50 dark:border-gray-700/50 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-gradient-to-r from-purple-600 to-pink-600 rounded-xl flex items-center justify-center shadow-lg">
                  <Settings className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h1 className="text-xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                    Admin Panel
                  </h1>
                  <p className="text-xs text-gray-500 dark:text-gray-400">Content Management System</p>
                </div>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <Button variant="outline" size="sm">
                <Upload className="w-4 h-4 mr-2" />
                Import Data
              </Button>
              <Button variant="outline" size="sm">
                <Download className="w-4 h-4 mr-2" />
                Export Data
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-4 mb-8">
            <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
            <TabsTrigger value="mcqs">MCQ Management</TabsTrigger>
            <TabsTrigger value="exams">Exam Management</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard" className="space-y-8">
            {/* Stats Overview */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
            >
              <MaterialCard>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Total MCQs</p>
                      <p className="text-3xl font-bold text-blue-600">{stats.totalMCQs}</p>
                      <p className="text-xs text-green-600">{stats.activeMCQs} active</p>
                    </div>
                    <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-blue-600 rounded-xl flex items-center justify-center">
                      <BookOpen className="w-6 h-6 text-white" />
                    </div>
                  </div>
                </CardContent>
              </MaterialCard>

              <MaterialCard>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Upcoming Exams</p>
                      <p className="text-3xl font-bold text-green-600">{stats.totalExams}</p>
                      <p className="text-xs text-green-600">{stats.activeExams} active</p>
                    </div>
                    <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-green-600 rounded-xl flex items-center justify-center">
                      <Calendar className="w-6 h-6 text-white" />
                    </div>
                  </div>
                </CardContent>
              </MaterialCard>

              <MaterialCard>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Categories</p>
                      <p className="text-3xl font-bold text-purple-600">{stats.categories}</p>
                      <p className="text-xs text-purple-600">{stats.subjects} subjects</p>
                    </div>
                    <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-purple-600 rounded-xl flex items-center justify-center">
                      <Target className="w-6 h-6 text-white" />
                    </div>
                  </div>
                </CardContent>
              </MaterialCard>
            </motion.div>

            {/* Quick Actions */}
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
              <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">Quick Actions</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <MaterialCard
                  className="hover:shadow-lg transition-shadow cursor-pointer"
                  onClick={() => setIsAddMCQOpen(true)}
                >
                  <CardContent className="p-6 text-center">
                    <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-blue-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                      <Plus className="w-6 h-6 text-white" />
                    </div>
                    <h4 className="font-semibold mb-2">Add MCQ</h4>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Create new question</p>
                  </CardContent>
                </MaterialCard>

                <MaterialCard
                  className="hover:shadow-lg transition-shadow cursor-pointer"
                  onClick={() => setIsAddExamOpen(true)}
                >
                  <CardContent className="p-6 text-center">
                    <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-green-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                      <Calendar className="w-6 h-6 text-white" />
                    </div>
                    <h4 className="font-semibold mb-2">Add Exam</h4>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Schedule new exam</p>
                  </CardContent>
                </MaterialCard>

                <MaterialCard className="hover:shadow-lg transition-shadow cursor-pointer">
                  <CardContent className="p-6 text-center">
                    <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-purple-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                      <Upload className="w-6 h-6 text-white" />
                    </div>
                    <h4 className="font-semibold mb-2">Bulk Import</h4>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Import CSV/Excel</p>
                  </CardContent>
                </MaterialCard>

                <MaterialCard className="hover:shadow-lg transition-shadow cursor-pointer">
                  <CardContent className="p-6 text-center">
                    <div className="w-12 h-12 bg-gradient-to-r from-orange-500 to-orange-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                      <BarChart3 className="w-6 h-6 text-white" />
                    </div>
                    <h4 className="font-semibold mb-2">Analytics</h4>
                    <p className="text-sm text-gray-600 dark:text-gray-400">View reports</p>
                  </CardContent>
                </MaterialCard>
              </div>
            </motion.div>
          </TabsContent>

          <TabsContent value="mcqs" className="space-y-6">
            {/* MCQ Management Header */}
            <div className="flex items-center justify-between">
              <h3 className="text-2xl font-bold text-gray-900 dark:text-white">MCQ Management</h3>
              <Button onClick={() => setIsAddMCQOpen(true)} className="bg-gradient-to-r from-blue-500 to-purple-600">
                <Plus className="w-4 h-4 mr-2" />
                Add New MCQ
              </Button>
            </div>

            {/* Filters */}
            <MaterialCard>
              <CardContent className="p-6">
                <div className="flex flex-col md:flex-row gap-4">
                  <div className="flex-1">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                      <Input
                        placeholder="Search MCQs..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="pl-10"
                      />
                    </div>
                  </div>
                  <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                    <SelectTrigger className="w-48">
                      <SelectValue placeholder="Filter by category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Categories</SelectItem>
                      <SelectItem value="PPSC">PPSC</SelectItem>
                      <SelectItem value="FPSC">FPSC</SelectItem>
                      <SelectItem value="CSS">CSS</SelectItem>
                      <SelectItem value="MPT">MPT</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </MaterialCard>

            {/* MCQ List */}
            <div className="space-y-4">
              {filteredMCQs.map((mcq, index) => (
                <MaterialCard key={mcq.id}>
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-3 mb-3">
                          <Badge variant="outline">{mcq.category}</Badge>
                          <Badge
                            variant={
                              mcq.difficulty === "Easy"
                                ? "default"
                                : mcq.difficulty === "Medium"
                                  ? "secondary"
                                  : "destructive"
                            }
                          >
                            {mcq.difficulty}
                          </Badge>
                          <Badge variant="secondary">{mcq.subject}</Badge>
                          <Switch checked={mcq.isActive} onCheckedChange={() => handleToggleMCQStatus(mcq.id)} />
                        </div>
                        <h4 className="font-semibold text-lg mb-3">{mcq.question}</h4>
                        <div className="grid grid-cols-2 gap-2 mb-3">
                          {mcq.options.map((option, optIndex) => (
                            <div
                              key={optIndex}
                              className={`p-2 rounded-lg text-sm ${
                                optIndex === mcq.correctAnswer
                                  ? "bg-green-100 dark:bg-green-900/20 border border-green-300 dark:border-green-700"
                                  : "bg-gray-100 dark:bg-gray-800 border border-gray-200 dark:border-gray-700"
                              }`}
                            >
                              <span className="font-medium">{String.fromCharCode(65 + optIndex)}.</span> {option}
                            </div>
                          ))}
                        </div>
                        <p className="text-sm text-gray-600 dark:text-gray-400">
                          <strong>Explanation:</strong> {mcq.explanation}
                        </p>
                      </div>
                      <div className="flex items-center space-x-2 ml-4">
                        <Button variant="outline" size="sm">
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button variant="outline" size="sm">
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => handleDeleteMCQ(mcq.id)}>
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </MaterialCard>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="exams" className="space-y-6">
            {/* Exam Management Header */}
            <div className="flex items-center justify-between">
              <h3 className="text-2xl font-bold text-gray-900 dark:text-white">Exam Management</h3>
              <Button onClick={() => setIsAddExamOpen(true)} className="bg-gradient-to-r from-green-500 to-blue-600">
                <Plus className="w-4 h-4 mr-2" />
                Add New Exam
              </Button>
            </div>

            {/* Exam List */}
            <div className="space-y-4">
              {exams.map((exam) => (
                <MaterialCard key={exam.id}>
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-3 mb-3">
                          <Badge variant="outline">{exam.category}</Badge>
                          <Switch checked={exam.isActive} onCheckedChange={() => handleToggleExamStatus(exam.id)} />
                        </div>
                        <h4 className="font-semibold text-lg mb-3">{exam.title}</h4>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm mb-3">
                          <div>
                            <span className="text-gray-600 dark:text-gray-400">Date:</span>
                            <div className="font-medium">{exam.date}</div>
                          </div>
                          <div>
                            <span className="text-gray-600 dark:text-gray-400">Time:</span>
                            <div className="font-medium">{exam.time}</div>
                          </div>
                          <div>
                            <span className="text-gray-600 dark:text-gray-400">Posts:</span>
                            <div className="font-medium">{exam.posts}</div>
                          </div>
                          <div>
                            <span className="text-gray-600 dark:text-gray-400">Fee:</span>
                            <div className="font-medium">{exam.fee}</div>
                          </div>
                        </div>
                        <p className="text-sm text-gray-600 dark:text-gray-400">
                          <strong>Location:</strong> {exam.location}
                        </p>
                        <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                          <strong>Application Deadline:</strong> {exam.applicationDeadline}
                        </p>
                        <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">{exam.description}</p>
                      </div>
                      <div className="flex items-center space-x-2 ml-4">
                        <Button variant="outline" size="sm">
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => handleDeleteExam(exam.id)}>
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </MaterialCard>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            <h3 className="text-2xl font-bold text-gray-900 dark:text-white">Analytics & Reports</h3>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <MaterialCard>
                <CardContent className="p-6 text-center">
                  <div className="text-3xl font-bold text-blue-600 mb-2">1,234</div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">Total Users</div>
                  <div className="text-xs text-green-600 mt-1">+12% this month</div>
                </CardContent>
              </MaterialCard>

              <MaterialCard>
                <CardContent className="p-6 text-center">
                  <div className="text-3xl font-bold text-green-600 mb-2">5,678</div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">Tests Taken</div>
                  <div className="text-xs text-green-600 mt-1">+25% this month</div>
                </CardContent>
              </MaterialCard>

              <MaterialCard>
                <CardContent className="p-6 text-center">
                  <div className="text-3xl font-bold text-purple-600 mb-2">78%</div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">Avg Score</div>
                  <div className="text-xs text-green-600 mt-1">+3% improvement</div>
                </CardContent>
              </MaterialCard>

              <MaterialCard>
                <CardContent className="p-6 text-center">
                  <div className="text-3xl font-bold text-orange-600 mb-2">456</div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">Active Users</div>
                  <div className="text-xs text-green-600 mt-1">+8% this week</div>
                </CardContent>
              </MaterialCard>
            </div>
          </TabsContent>
        </Tabs>

        {/* Add MCQ Dialog */}
        <Dialog open={isAddMCQOpen} onOpenChange={setIsAddMCQOpen}>
          <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Add New MCQ</DialogTitle>
            </DialogHeader>
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="category">Category</Label>
                  <Select value={newMCQ.category} onValueChange={(value) => setNewMCQ({ ...newMCQ, category: value })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="PPSC">PPSC</SelectItem>
                      <SelectItem value="FPSC">FPSC</SelectItem>
                      <SelectItem value="CSS">CSS</SelectItem>
                      <SelectItem value="MPT">MPT</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="difficulty">Difficulty</Label>
                  <Select
                    value={newMCQ.difficulty}
                    onValueChange={(value: "Easy" | "Medium" | "Hard") => setNewMCQ({ ...newMCQ, difficulty: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Easy">Easy</SelectItem>
                      <SelectItem value="Medium">Medium</SelectItem>
                      <SelectItem value="Hard">Hard</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label htmlFor="subject">Subject</Label>
                <Input
                  id="subject"
                  value={newMCQ.subject}
                  onChange={(e) => setNewMCQ({ ...newMCQ, subject: e.target.value })}
                  placeholder="e.g., General Knowledge, Pakistan Studies"
                />
              </div>

              <div>
                <Label htmlFor="question">Question</Label>
                <Textarea
                  id="question"
                  value={newMCQ.question}
                  onChange={(e) => setNewMCQ({ ...newMCQ, question: e.target.value })}
                  placeholder="Enter your question here..."
                  rows={3}
                />
              </div>

              <div>
                <Label>Options</Label>
                <div className="space-y-2">
                  {newMCQ.options?.map((option, index) => (
                    <div key={index} className="flex items-center space-x-2">
                      <Input
                        value={option}
                        onChange={(e) => {
                          const newOptions = [...(newMCQ.options || [])]
                          newOptions[index] = e.target.value
                          setNewMCQ({ ...newMCQ, options: newOptions })
                        }}
                        placeholder={`Option ${String.fromCharCode(65 + index)}`}
                      />
                      <Button
                        type="button"
                        variant={newMCQ.correctAnswer === index ? "default" : "outline"}
                        size="sm"
                        onClick={() => setNewMCQ({ ...newMCQ, correctAnswer: index })}
                      >
                        {newMCQ.correctAnswer === index ? "Correct" : "Mark Correct"}
                      </Button>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <Label htmlFor="explanation">Explanation</Label>
                <Textarea
                  id="explanation"
                  value={newMCQ.explanation}
                  onChange={(e) => setNewMCQ({ ...newMCQ, explanation: e.target.value })}
                  placeholder="Explain why this answer is correct..."
                  rows={3}
                />
              </div>

              <div className="flex items-center space-x-2">
                <Switch
                  checked={newMCQ.isActive}
                  onCheckedChange={(checked) => setNewMCQ({ ...newMCQ, isActive: checked })}
                />
                <Label>Active</Label>
              </div>

              <div className="flex justify-end space-x-3">
                <Button variant="outline" onClick={() => setIsAddMCQOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleAddMCQ}>
                  <Save className="w-4 h-4 mr-2" />
                  Save MCQ
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Add Exam Dialog */}
        <Dialog open={isAddExamOpen} onOpenChange={setIsAddExamOpen}>
          <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Add New Exam</DialogTitle>
            </DialogHeader>
            <div className="space-y-6">
              <div>
                <Label htmlFor="examTitle">Exam Title</Label>
                <Input
                  id="examTitle"
                  value={newExam.title}
                  onChange={(e) => setNewExam({ ...newExam, title: e.target.value })}
                  placeholder="e.g., PPSC Lecturer (Education) - BPS-17"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="examDate">Date</Label>
                  <Input
                    id="examDate"
                    type="date"
                    value={newExam.date}
                    onChange={(e) => setNewExam({ ...newExam, date: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="examTime">Time</Label>
                  <Input
                    id="examTime"
                    type="time"
                    value={newExam.time}
                    onChange={(e) => setNewExam({ ...newExam, time: e.target.value })}
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="examLocation">Location</Label>
                <Input
                  id="examLocation"
                  value={newExam.location}
                  onChange={(e) => setNewExam({ ...newExam, location: e.target.value })}
                  placeholder="e.g., Lahore, Karachi, Islamabad"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="examCategory">Category</Label>
                  <Select
                    value={newExam.category}
                    onValueChange={(value) => setNewExam({ ...newExam, category: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="PPSC">PPSC</SelectItem>
                      <SelectItem value="FPSC">FPSC</SelectItem>
                      <SelectItem value="CSS">CSS</SelectItem>
                      <SelectItem value="MPT">MPT</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="examPosts">Number of Posts</Label>
                  <Input
                    id="examPosts"
                    type="number"
                    value={newExam.posts}
                    onChange={(e) => setNewExam({ ...newExam, posts: Number.parseInt(e.target.value) || 0 })}
                    placeholder="e.g., 45"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="applicationDeadline">Application Deadline</Label>
                  <Input
                    id="applicationDeadline"
                    type="date"
                    value={newExam.applicationDeadline}
                    onChange={(e) => setNewExam({ ...newExam, applicationDeadline: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="examFee">Fee</Label>
                  <Input
                    id="examFee"
                    value={newExam.fee}
                    onChange={(e) => setNewExam({ ...newExam, fee: e.target.value })}
                    placeholder="e.g., Rs. 500"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="examDescription">Description</Label>
                <Textarea
                  id="examDescription"
                  value={newExam.description}
                  onChange={(e) => setNewExam({ ...newExam, description: e.target.value })}
                  placeholder="Brief description of the exam..."
                  rows={3}
                />
              </div>

              <div className="flex items-center space-x-2">
                <Switch
                  checked={newExam.isActive}
                  onCheckedChange={(checked) => setNewExam({ ...newExam, isActive: checked })}
                />
                <Label>Active</Label>
              </div>

              <div className="flex justify-end space-x-3">
                <Button variant="outline" onClick={() => setIsAddExamOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleAddExam}>
                  <Save className="w-4 h-4 mr-2" />
                  Save Exam
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </main>
    </div>
  )
}
