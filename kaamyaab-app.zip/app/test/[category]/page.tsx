"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import { motion } from "framer-motion"
import {
  ArrowLeft,
  Calendar,
  FileText,
  Play,
  Shuffle,
  TrendingUp,
  BookOpen,
  Star,
  ChevronRight,
  Download,
  Share2,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { MaterialCard } from "@/components/material-card"
import { MCQDialog } from "@/components/mcq-dialog"

const categoryData = {
  ppsc: {
    name: "PPSC",
    fullName: "Punjab Public Service Commission",
    description:
      "Prepare for Punjab Public Service Commission examinations with comprehensive study materials and practice tests.",
    icon: "🏛️",
    color: "from-blue-500 to-blue-600",
    subjects: [
      "General Knowledge",
      "Current Affairs",
      "Pakistan Studies",
      "English",
      "Mathematics",
      "Computer Science",
    ],
  },
  fpsc: {
    name: "FPSC",
    fullName: "Federal Public Service Commission",
    description:
      "Excel in Federal Public Service Commission tests with our expertly curated content and practice materials.",
    icon: "🎓",
    color: "from-green-500 to-green-600",
    subjects: ["General Knowledge", "Current Affairs", "English", "Mathematics", "Pakistan Studies", "Islamic Studies"],
  },
  css: {
    name: "CSS",
    fullName: "Central Superior Services",
    description: "Master the Central Superior Services examination with our comprehensive preparation platform.",
    icon: "📜",
    color: "from-purple-500 to-purple-600",
    subjects: [
      "Essay Writing",
      "General Knowledge",
      "Current Affairs",
      "Pakistan Affairs",
      "English",
      "Optional Subjects",
    ],
  },
  gk: {
    name: "General Knowledge",
    fullName: "General Knowledge Tests",
    description: "Build a strong foundation in general knowledge across various subjects and topics.",
    icon: "🌍",
    color: "from-orange-500 to-orange-600",
    subjects: ["World History", "Geography", "Science", "Current Events", "Sports", "Arts & Culture"],
  },
  english: {
    name: "English",
    fullName: "English Language Tests",
    description: "Improve your English language skills with comprehensive grammar and vocabulary practice.",
    icon: "📚",
    color: "from-teal-500 to-teal-600",
    subjects: ["Grammar", "Vocabulary", "Comprehension", "Writing", "Literature", "Phonetics"],
  },
  history: {
    name: "History",
    fullName: "History & Pakistan Studies",
    description: "Explore historical events and Pakistan's rich heritage through detailed study materials.",
    icon: "🕰️",
    color: "from-amber-500 to-amber-600",
    subjects: [
      "World History",
      "Pakistan History",
      "Islamic History",
      "Modern History",
      "Ancient Civilizations",
      "Geography",
    ],
  },
}

const upcomingExams = [
  {
    id: 1,
    title: "PPSC Lecturer (Education) - BPS-17",
    date: "2024-01-15",
    time: "10:00 AM",
    location: "Lahore, Faisalabad, Multan",
    applicationDeadline: "2024-01-05",
    fee: "Rs. 500",
    posts: 45,
    category: "Education",
  },
  {
    id: 2,
    title: "PPSC Assistant Director (Local Government) - BPS-17",
    date: "2024-01-22",
    time: "2:00 PM",
    location: "Lahore, Rawalpindi",
    applicationDeadline: "2024-01-10",
    fee: "Rs. 600",
    posts: 12,
    category: "Administration",
  },
]

const pastPapers = [
  {
    id: 1,
    title: "PPSC Lecturer Education 2023",
    year: "2023",
    subject: "General Knowledge + Education",
    questions: 100,
    duration: "2 hours",
    difficulty: "Medium",
    downloads: 1250,
  },
  {
    id: 2,
    title: "PPSC Assistant Director 2023",
    year: "2023",
    subject: "General Knowledge + Administration",
    questions: 80,
    duration: "1.5 hours",
    difficulty: "Hard",
    downloads: 890,
  },
]

export default function TestCategoryPage() {
  const params = useParams()
  const router = useRouter()
  const [activeTab, setActiveTab] = useState("overview")
  const [showMCQDialog, setShowMCQDialog] = useState(false)
  const [testData, setTestData] = useState(null)
  const category = params.category as string
  const data = categoryData[category as keyof typeof categoryData]

  // Load category stats from localStorage
  const [categoryStats, setCategoryStats] = useState({
    totalTests: 100,
    completedTests: 0,
    averageScore: 0,
    studyTime: 0,
    rank: 0,
  })

  useEffect(() => {
    if (data) {
      loadCategoryStats()
    }
  }, [category, data])

  const loadCategoryStats = () => {
    const testSessions = JSON.parse(localStorage.getItem("kaamyaab_test_sessions") || "[]")
    const categorySessions = testSessions.filter((session: any) => session.category === category)

    const totalScore = categorySessions.reduce((sum: number, session: any) => sum + (session.score || 0), 0)
    const totalTime = categorySessions.reduce((sum: number, session: any) => sum + (session.timeSpent || 0), 0)

    setCategoryStats({
      totalTests: 100,
      completedTests: categorySessions.length,
      averageScore: categorySessions.length > 0 ? Math.round(totalScore / categorySessions.length) : 0,
      studyTime: Math.round(totalTime / 60), // Convert to hours
      rank: Math.max(1, 15 - categorySessions.length), // Mock ranking based on activity
    })
  }

  const createPracticeTest = () => {
    const test = {
      id: Date.now().toString(),
      name: `${data.name} Practice Test`,
      category: category,
      difficulty: "Medium" as const,
      mcqCount: 15,
      progress: 0,
      lastStudied: "Now",
      color: "bg-blue-500",
      averageScore: categoryStats.averageScore,
      timeSpent: categoryStats.studyTime,
      streak: 0,
      bestScore: 0,
      attempts: categoryStats.completedTests,
    }

    setTestData(test)
    setShowMCQDialog(true)
  }

  const handleScoreUpdate = (score: number, timeSpent: number) => {
    // Save test session to localStorage
    const testSession = {
      id: Date.now().toString(),
      category: category,
      score,
      timeSpent,
      date: new Date().toISOString(),
      difficulty: "Medium",
      questionCount: 15,
    }

    const existingSessions = JSON.parse(localStorage.getItem("kaamyaab_test_sessions") || "[]")
    existingSessions.push(testSession)
    localStorage.setItem("kaamyaab_test_sessions", JSON.stringify(existingSessions))

    // Reload stats
    loadCategoryStats()
  }

  if (!data) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Category Not Found</h1>
          <Button onClick={() => router.push("/dashboard")}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Dashboard
          </Button>
        </div>
      </div>
    )
  }

  const progressPercentage = (categoryStats.completedTests / categoryStats.totalTests) * 100

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 dark:from-gray-950 dark:via-blue-950 dark:to-indigo-950">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/90 dark:bg-gray-900/90 backdrop-blur-xl border-b border-gray-200/50 dark:border-gray-700/50 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="icon" onClick={() => router.push("/dashboard")}>
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <div className="flex items-center space-x-3">
                <div className="text-2xl">{data.icon}</div>
                <div>
                  <h1 className="text-xl font-bold text-gray-900 dark:text-white">{data.name}</h1>
                  <p className="text-sm text-gray-600 dark:text-gray-400">{data.fullName}</p>
                </div>
              </div>
            </div>

            <div className="flex items-center space-x-3">
              <Button variant="outline" size="sm">
                <Share2 className="w-4 h-4 mr-2" />
                Share
              </Button>
              <Button onClick={createPracticeTest} className="bg-gradient-to-r from-blue-500 to-purple-600">
                <Play className="w-4 h-4 mr-2" />
                Start Test
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero Section */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
          <div className="text-center mb-8">
            <h2 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">Master {data.name} Examinations</h2>
            <p className="text-lg text-gray-600 dark:text-gray-400 max-w-3xl mx-auto">{data.description}</p>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-8">
            <MaterialCard>
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-blue-600">{categoryStats.totalTests}</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Total Tests</div>
              </CardContent>
            </MaterialCard>
            <MaterialCard>
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-green-600">{categoryStats.completedTests}</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Completed</div>
              </CardContent>
            </MaterialCard>
            <MaterialCard>
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-purple-600">{categoryStats.averageScore}%</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Avg Score</div>
              </CardContent>
            </MaterialCard>
            <MaterialCard>
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-orange-600">{categoryStats.studyTime}h</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Study Time</div>
              </CardContent>
            </MaterialCard>
            <MaterialCard>
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-red-600">#{categoryStats.rank}</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Your Rank</div>
              </CardContent>
            </MaterialCard>
          </div>

          {/* Progress Bar */}
          <MaterialCard>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">Overall Progress</h3>
                <Badge variant="secondary">{Math.round(progressPercentage)}%</Badge>
              </div>
              <Progress value={progressPercentage} className="h-3 mb-2" />
              <div className="flex justify-between text-sm text-gray-600 dark:text-gray-400">
                <span>{categoryStats.completedTests} tests completed</span>
                <span>{categoryStats.totalTests - categoryStats.completedTests} remaining</span>
              </div>
            </CardContent>
          </MaterialCard>
        </motion.div>

        {/* Quick Actions */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8"
        >
          <MaterialCard className="hover:shadow-lg transition-shadow cursor-pointer" onClick={createPracticeTest}>
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-blue-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                <Play className="w-6 h-6 text-white" />
              </div>
              <h3 className="font-semibold mb-2">Practice Test</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">Take a comprehensive practice test</p>
            </CardContent>
          </MaterialCard>

          <MaterialCard className="hover:shadow-lg transition-shadow cursor-pointer">
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-green-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                <Shuffle className="w-6 h-6 text-white" />
              </div>
              <h3 className="font-semibold mb-2">Random Quiz</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">Quick random questions</p>
            </CardContent>
          </MaterialCard>

          <MaterialCard className="hover:shadow-lg transition-shadow cursor-pointer">
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-purple-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                <FileText className="w-6 h-6 text-white" />
              </div>
              <h3 className="font-semibold mb-2">Past Papers</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">Previous exam papers</p>
            </CardContent>
          </MaterialCard>

          <MaterialCard className="hover:shadow-lg transition-shadow cursor-pointer">
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 bg-gradient-to-r from-orange-500 to-orange-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                <TrendingUp className="w-6 h-6 text-white" />
              </div>
              <h3 className="font-semibold mb-2">Analytics</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">View detailed progress</p>
            </CardContent>
          </MaterialCard>
        </motion.div>

        {/* Tabs Section */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-3 mb-8">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="upcoming">Upcoming Exams</TabsTrigger>
              <TabsTrigger value="papers">Past Papers</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-6">
              {/* Subjects */}
              <MaterialCard>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <BookOpen className="w-5 h-5 text-blue-600" />
                    <span>Subject Areas</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {data.subjects.map((subject, index) => (
                      <div
                        key={subject}
                        className="p-4 rounded-lg border border-gray-200 dark:border-gray-700 hover:shadow-md transition-shadow cursor-pointer"
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-medium">{subject}</span>
                          <ChevronRight className="w-4 h-4 text-gray-400" />
                        </div>
                        <div className="mt-2">
                          <Progress value={Math.random() * 100} className="h-2" />
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </MaterialCard>

              {/* Recent Performance */}
              <MaterialCard>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <TrendingUp className="w-5 h-5 text-green-600" />
                    <span>Recent Performance</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {categoryStats.completedTests > 0 ? (
                      // Show actual test results
                      JSON.parse(localStorage.getItem("kaamyaab_test_sessions") || "[]")
                        .filter((session: any) => session.category === category)
                        .slice(-3)
                        .map((session: any, index: number) => (
                          <div
                            key={index}
                            className="flex items-center justify-between p-4 rounded-lg bg-gray-50 dark:bg-gray-800/50"
                          >
                            <div>
                              <h4 className="font-medium">{data.name} Practice Test</h4>
                              <p className="text-sm text-gray-600 dark:text-gray-400">
                                {session.questionCount} questions • {new Date(session.date).toLocaleDateString()}
                              </p>
                            </div>
                            <div className="text-right">
                              <div
                                className={`text-lg font-bold ${
                                  session.score >= 80
                                    ? "text-green-600"
                                    : session.score >= 60
                                      ? "text-yellow-600"
                                      : "text-red-600"
                                }`}
                              >
                                {session.score}%
                              </div>
                              <div className="flex items-center space-x-1">
                                {[...Array(5)].map((_, i) => (
                                  <Star
                                    key={i}
                                    className={`w-3 h-3 ${
                                      i < Math.floor(session.score / 20)
                                        ? "text-yellow-400 fill-current"
                                        : "text-gray-300"
                                    }`}
                                  />
                                ))}
                              </div>
                            </div>
                          </div>
                        ))
                    ) : (
                      <div className="text-center py-8">
                        <BookOpen className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                        <h4 className="font-medium text-lg mb-2">No tests taken yet</h4>
                        <p className="text-gray-600 dark:text-gray-400 mb-4">
                          Start your first practice test to see your performance here
                        </p>
                        <Button onClick={createPracticeTest}>
                          <Play className="w-4 h-4 mr-2" />
                          Take First Test
                        </Button>
                      </div>
                    )}
                  </div>
                </CardContent>
              </MaterialCard>
            </TabsContent>

            <TabsContent value="upcoming" className="space-y-6">
              <div className="grid grid-cols-1 gap-6">
                {upcomingExams.map((exam) => (
                  <MaterialCard key={exam.id}>
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex-1">
                          <h3 className="text-lg font-semibold mb-2">{exam.title}</h3>
                          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                            <div>
                              <span className="text-gray-600 dark:text-gray-400">Date:</span>
                              <div className="font-medium">{exam.date}</div>
                            </div>
                            <div>
                              <span className="text-gray-600 dark:text-gray-400">Time:</span>
                              <div className="font-medium">{exam.time}</div>
                            </div>
                            <div>
                              <span className="text-gray-600 dark:text-gray-400">Posts:</span>
                              <div className="font-medium">{exam.posts}</div>
                            </div>
                            <div>
                              <span className="text-gray-600 dark:text-gray-400">Fee:</span>
                              <div className="font-medium">{exam.fee}</div>
                            </div>
                          </div>
                        </div>
                        <Badge variant="outline">{exam.category}</Badge>
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="text-sm text-gray-600 dark:text-gray-400">
                          <span>Application Deadline: </span>
                          <span className="font-medium text-red-600">{exam.applicationDeadline}</span>
                        </div>
                        <div className="flex space-x-2">
                          <Button variant="outline" size="sm">
                            <Calendar className="w-4 h-4 mr-2" />
                            Add to Calendar
                          </Button>
                          <Button size="sm">Apply Now</Button>
                        </div>
                      </div>
                    </CardContent>
                  </MaterialCard>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="papers" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {pastPapers.map((paper) => (
                  <MaterialCard key={paper.id}>
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex-1">
                          <h3 className="font-semibold mb-2">{paper.title}</h3>
                          <div className="space-y-2 text-sm">
                            <div className="flex justify-between">
                              <span className="text-gray-600 dark:text-gray-400">Year:</span>
                              <span className="font-medium">{paper.year}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-600 dark:text-gray-400">Questions:</span>
                              <span className="font-medium">{paper.questions}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-600 dark:text-gray-400">Duration:</span>
                              <span className="font-medium">{paper.duration}</span>
                            </div>
                          </div>
                        </div>
                        <Badge
                          variant={
                            paper.difficulty === "Easy"
                              ? "default"
                              : paper.difficulty === "Medium"
                                ? "secondary"
                                : "destructive"
                          }
                        >
                          {paper.difficulty}
                        </Badge>
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="text-sm text-gray-600 dark:text-gray-400">
                          <Download className="w-4 h-4 inline mr-1" />
                          {paper.downloads} downloads
                        </div>
                        <div className="flex space-x-2">
                          <Button variant="outline" size="sm">
                            <Download className="w-4 h-4 mr-2" />
                            Download
                          </Button>
                          <Button size="sm">
                            <Play className="w-4 h-4 mr-2" />
                            Practice
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </MaterialCard>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </motion.div>
      </main>

      {/* MCQ Dialog */}
      <MCQDialog
        open={showMCQDialog}
        onOpenChange={setShowMCQDialog}
        test={testData}
        onScoreUpdate={handleScoreUpdate}
      />
    </div>
  )
}
