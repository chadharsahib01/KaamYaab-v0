"use client"

import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { CheckCircle, XCircle, Clock, Trophy, RotateCcw, Zap, Target, Brain, Star } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"

interface Test {
  id: string
  name: string
  link: string
  progress: number
  category: string
  color: string
  mcqCount: number
  lastStudied: string
  difficulty: "Easy" | "Medium" | "Hard"
  averageScore: number
  timeSpent: number
  streak: number
  bestScore: number
  attempts: number
}

interface MCQ {
  id: string
  question: string
  options: string[]
  correctAnswer: number
  explanation: string
  difficulty: "Easy" | "Medium" | "Hard"
  category: string
  timeLimit: number
}

interface MCQDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  test: Test | null
  onScoreUpdate?: (score: number, timeSpent: number) => void
}

const sampleMCQs: MCQ[] = [
  {
    id: "1",
    question: "What is the capital of Pakistan?",
    options: ["Karachi", "Lahore", "Islamabad", "Peshawar"],
    correctAnswer: 2,
    explanation: "Islamabad is the capital city of Pakistan, established in 1960 as a planned city to replace Karachi.",
    difficulty: "Easy",
    category: "General Knowledge",
    timeLimit: 30,
  },
  {
    id: "2",
    question: "Who was the founder of Pakistan?",
    options: ["Allama Iqbal", "Quaid-e-Azam Muhammad Ali Jinnah", "Liaquat Ali Khan", "Sir Syed Ahmad Khan"],
    correctAnswer: 1,
    explanation: "Quaid-e-Azam Muhammad Ali Jinnah is known as the founder of Pakistan and led the Pakistan movement.",
    difficulty: "Easy",
    category: "Pakistan Studies",
    timeLimit: 25,
  },
  {
    id: "3",
    question: "In which year did Pakistan become an Islamic Republic?",
    options: ["1947", "1956", "1973", "1962"],
    correctAnswer: 1,
    explanation: "Pakistan became an Islamic Republic in 1956 with the adoption of its first constitution.",
    difficulty: "Medium",
    category: "Pakistan Studies",
    timeLimit: 35,
  },
  {
    id: "4",
    question: "What is the highest peak in Pakistan?",
    options: ["Nanga Parbat", "K2", "Tirich Mir", "Rakaposhi"],
    correctAnswer: 1,
    explanation: "K2 is the highest peak in Pakistan and the second highest mountain in the world at 8,611 meters.",
    difficulty: "Medium",
    category: "General Knowledge",
    timeLimit: 30,
  },
  {
    id: "5",
    question: "Which river is called the lifeline of Pakistan?",
    options: ["Chenab", "Ravi", "Indus", "Jhelum"],
    correctAnswer: 2,
    explanation:
      "The Indus River is called the lifeline of Pakistan as it provides water for irrigation and supports agriculture.",
    difficulty: "Easy",
    category: "General Knowledge",
    timeLimit: 25,
  },
]

export function MCQDialog({ open, onOpenChange, test, onScoreUpdate }: MCQDialogProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null)
  const [showResult, setShowResult] = useState(false)
  const [showExplanation, setShowExplanation] = useState(false)
  const [score, setScore] = useState(0)
  const [answers, setAnswers] = useState<(number | null)[]>([])
  const [timeLeft, setTimeLeft] = useState(30)
  const [isActive, setIsActive] = useState(false)
  const [startTime, setStartTime] = useState<number>(0)
  const [totalTimeSpent, setTotalTimeSpent] = useState(0)
  const [streak, setStreak] = useState(0)
  const [perfectAnswers, setPerfectAnswers] = useState(0)

  useEffect(() => {
    if (open && test) {
      resetQuiz()
    }
  }, [open, test])

  useEffect(() => {
    let interval: NodeJS.Timeout | null = null

    if (isActive && timeLeft > 0 && !showResult && !showExplanation) {
      interval = setInterval(() => {
        setTimeLeft((timeLeft) => timeLeft - 1)
      }, 1000)
    } else if (timeLeft === 0 && !showResult && !showExplanation) {
      handleAnswerSubmit()
    }

    return () => {
      if (interval) clearInterval(interval)
    }
  }, [isActive, timeLeft, showResult, showExplanation])

  const resetQuiz = () => {
    const questionCount = test?.mcqCount || 5
    const questionsToUse = sampleMCQs.slice(0, questionCount)

    setCurrentQuestion(0)
    setSelectedAnswer(null)
    setShowResult(false)
    setShowExplanation(false)
    setScore(0)
    setAnswers(new Array(questionCount).fill(null))
    setTimeLeft(questionsToUse[0]?.timeLimit || 30)
    setIsActive(true)
    setStartTime(Date.now())
    setTotalTimeSpent(0)
    setStreak(0)
    setPerfectAnswers(0)
  }

  const handleAnswerSelect = (answerIndex: number) => {
    if (!showExplanation) {
      setSelectedAnswer(answerIndex)
    }
  }

  const handleAnswerSubmit = () => {
    if (selectedAnswer === null && timeLeft > 0) return

    const questionCount = test?.mcqCount || 5
    const questionsToUse = sampleMCQs.slice(0, questionCount)

    const newAnswers = [...answers]
    newAnswers[currentQuestion] = selectedAnswer
    setAnswers(newAnswers)

    const isCorrect = selectedAnswer === questionsToUse[currentQuestion].correctAnswer
    const timeBonus = timeLeft > 0 ? Math.floor(timeLeft / 5) : 0

    if (isCorrect) {
      setScore(score + 1)
      setStreak(streak + 1)
      if (timeLeft > questionsToUse[currentQuestion].timeLimit * 0.7) {
        setPerfectAnswers(perfectAnswers + 1)
      }
    } else {
      setStreak(0)
    }

    setShowExplanation(true)
    setIsActive(false)
  }

  const handleNext = () => {
    const questionCount = test?.mcqCount || 5
    const questionsToUse = sampleMCQs.slice(0, questionCount)

    if (currentQuestion < questionCount - 1) {
      setCurrentQuestion(currentQuestion + 1)
      setSelectedAnswer(null)
      setShowExplanation(false)
      setTimeLeft(questionsToUse[currentQuestion + 1]?.timeLimit || 30)
      setIsActive(true)
    } else {
      const endTime = Date.now()
      const timeSpent = Math.round((endTime - startTime) / 1000 / 60) // in minutes
      setTotalTimeSpent(timeSpent)
      setShowResult(true)
      setIsActive(false)

      // Call the score update callback
      const finalScore = Math.round((score / questionCount) * 100)
      onScoreUpdate?.(finalScore, timeSpent)
    }
  }

  const handleRestart = () => {
    resetQuiz()
  }

  const handleClose = () => {
    setIsActive(false)
    onOpenChange(false)
  }

  if (!test) return null

  const questionCount = test.mcqCount || 5
  const questionsToUse = sampleMCQs.slice(0, questionCount)
  const currentMCQ = questionsToUse[currentQuestion]
  const progress = ((currentQuestion + 1) / questionCount) * 100
  const finalScore = Math.round((score / questionCount) * 100)
  const accuracy = answers.filter((answer, index) => answer === questionsToUse[index]?.correctAnswer).length

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-3xl max-h-[95vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div
                className={`w-3 h-3 rounded-full ${test.color.replace("bg-gradient-to-r", "bg-blue-500")} animate-pulse`}
              />
              <span>{test.name}</span>
              <Badge variant="outline" className="text-xs">
                {test.difficulty}
              </Badge>
            </div>
            {!showResult && !showExplanation && (
              <div className="flex items-center space-x-4">
                {streak > 0 && (
                  <div className="flex items-center space-x-1 text-orange-500">
                    <Zap className="w-4 h-4" />
                    <span className="text-sm font-medium">{streak}</span>
                  </div>
                )}
                <div className="flex items-center space-x-2">
                  <Clock className="w-4 h-4" />
                  <span className={`font-mono text-lg ${timeLeft <= 10 ? "text-red-500 animate-pulse" : ""}`}>
                    {Math.floor(timeLeft / 60)}:{(timeLeft % 60).toString().padStart(2, "0")}
                  </span>
                </div>
              </div>
            )}
          </DialogTitle>
        </DialogHeader>

        <AnimatePresence mode="wait">
          {!showResult ? (
            <motion.div
              key="quiz"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
              className="space-y-6"
            >
              {/* Enhanced Progress */}
              <div className="space-y-3">
                <div className="flex justify-between items-center text-sm">
                  <span className="flex items-center space-x-2">
                    <Brain className="w-4 h-4 text-blue-500" />
                    <span>
                      Question {currentQuestion + 1} of {questionCount}
                    </span>
                  </span>
                  <div className="flex items-center space-x-4">
                    <span className="flex items-center space-x-1">
                      <Target className="w-4 h-4 text-green-500" />
                      <span>
                        {score}/{questionCount}
                      </span>
                    </span>
                    <span>{Math.round(progress)}% Complete</span>
                  </div>
                </div>
                <div className="relative">
                  <Progress value={progress} className="h-3" />
                  <div
                    className="absolute top-0 left-0 h-3 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full transition-all duration-500"
                    style={{ width: `${progress}%` }}
                  />
                </div>
              </div>

              {/* Question Card */}
              <Card className="relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-blue-50 to-purple-50 dark:from-blue-900/10 dark:to-purple-900/10" />
                <CardContent className="relative pt-8 pb-6">
                  <div className="space-y-6">
                    <div className="flex items-center justify-between">
                      <Badge
                        variant={
                          currentMCQ.difficulty === "Easy"
                            ? "default"
                            : currentMCQ.difficulty === "Medium"
                              ? "secondary"
                              : "destructive"
                        }
                        className="text-xs"
                      >
                        {currentMCQ.difficulty}
                      </Badge>
                      <Badge variant="outline" className="text-xs">
                        {currentMCQ.category}
                      </Badge>
                    </div>

                    <h3 className="text-xl font-semibold leading-relaxed text-gray-800 dark:text-gray-200">
                      {currentMCQ.question}
                    </h3>

                    <div className="space-y-3">
                      {currentMCQ.options.map((option, index) => {
                        const isSelected = selectedAnswer === index
                        const isCorrect = index === currentMCQ.correctAnswer
                        const isWrong = showExplanation && isSelected && !isCorrect
                        const shouldHighlight = showExplanation && isCorrect

                        return (
                          <motion.button
                            key={index}
                            whileHover={{ scale: showExplanation ? 1 : 1.02 }}
                            whileTap={{ scale: showExplanation ? 1 : 0.98 }}
                            onClick={() => handleAnswerSelect(index)}
                            disabled={showExplanation}
                            className={`w-full p-4 text-left rounded-xl border-2 transition-all duration-300 ${
                              shouldHighlight
                                ? "border-green-500 bg-green-50 dark:bg-green-900/20 text-green-800 dark:text-green-200"
                                : isWrong
                                  ? "border-red-500 bg-red-50 dark:bg-red-900/20 text-red-800 dark:text-red-200"
                                  : isSelected
                                    ? "border-blue-500 bg-blue-50 dark:bg-blue-900/20 text-blue-800 dark:text-blue-200"
                                    : "border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-800/50"
                            }`}
                          >
                            <div className="flex items-center space-x-4">
                              <div
                                className={`w-8 h-8 rounded-full border-2 flex items-center justify-center text-sm font-medium ${
                                  shouldHighlight
                                    ? "border-green-500 bg-green-500 text-white"
                                    : isWrong
                                      ? "border-red-500 bg-red-500 text-white"
                                      : isSelected
                                        ? "border-blue-500 bg-blue-500 text-white"
                                        : "border-gray-300 dark:border-gray-600 text-gray-600 dark:text-gray-400"
                                }`}
                              >
                                {shouldHighlight ? (
                                  <CheckCircle className="w-4 h-4" />
                                ) : isWrong ? (
                                  <XCircle className="w-4 h-4" />
                                ) : (
                                  String.fromCharCode(65 + index)
                                )}
                              </div>
                              <span className="font-medium flex-1">{option}</span>
                            </div>
                          </motion.button>
                        )
                      })}
                    </div>

                    {/* Explanation */}
                    <AnimatePresence>
                      {showExplanation && (
                        <motion.div
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: "auto" }}
                          exit={{ opacity: 0, height: 0 }}
                          transition={{ duration: 0.3 }}
                          className="mt-6 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-700"
                        >
                          <div className="flex items-start space-x-3">
                            <div className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                              <Brain className="w-3 h-3 text-white" />
                            </div>
                            <div>
                              <h4 className="font-semibold text-blue-800 dark:text-blue-200 mb-2">Explanation</h4>
                              <p className="text-sm text-blue-700 dark:text-blue-300 leading-relaxed">
                                {currentMCQ.explanation}
                              </p>
                            </div>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                </CardContent>
              </Card>

              {/* Actions */}
              <div className="flex justify-between items-center">
                <Button variant="outline" onClick={handleClose} className="flex items-center space-x-2">
                  <XCircle className="w-4 h-4" />
                  <span>Exit Quiz</span>
                </Button>

                <div className="flex space-x-3">
                  {!showExplanation ? (
                    <Button
                      onClick={handleAnswerSubmit}
                      disabled={selectedAnswer === null}
                      className="min-w-24 flex items-center space-x-2"
                    >
                      <CheckCircle className="w-4 h-4" />
                      <span>Submit</span>
                    </Button>
                  ) : (
                    <Button onClick={handleNext} className="min-w-24 flex items-center space-x-2">
                      {currentQuestion === questionCount - 1 ? (
                        <>
                          <Trophy className="w-4 h-4" />
                          <span>Finish</span>
                        </>
                      ) : (
                        <>
                          <span>Next</span>
                          <span>→</span>
                        </>
                      )}
                    </Button>
                  )}
                </div>
              </div>
            </motion.div>
          ) : (
            /* Enhanced Results */
            <motion.div
              key="results"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5 }}
              className="space-y-8 text-center"
            >
              {/* Trophy Animation */}
              <motion.div
                initial={{ scale: 0, rotate: -180 }}
                animate={{ scale: 1, rotate: 0 }}
                transition={{ type: "spring", stiffness: 200, damping: 15, delay: 0.2 }}
                className="relative"
              >
                <div className="w-24 h-24 mx-auto bg-gradient-to-r from-yellow-400 via-yellow-500 to-yellow-600 rounded-full flex items-center justify-center shadow-2xl shadow-yellow-500/25">
                  <Trophy className="w-12 h-12 text-white" />
                </div>
                {finalScore >= 90 && (
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ delay: 0.5 }}
                    className="absolute -top-2 -right-2 w-8 h-8 bg-green-500 rounded-full flex items-center justify-center"
                  >
                    <Star className="w-4 h-4 text-white" />
                  </motion.div>
                )}
              </motion.div>

              {/* Results Header */}
              <div className="space-y-2">
                <motion.h3
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                  className="text-3xl font-bold text-gray-800 dark:text-gray-200"
                >
                  Quiz Completed! 🎉
                </motion.h3>
                <motion.p
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 }}
                  className="text-gray-600 dark:text-gray-400"
                >
                  Great job on completing the {test.name} quiz
                </motion.p>
              </div>

              {/* Score Display */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 }}
                className="bg-gradient-to-br from-blue-50 via-purple-50 to-indigo-50 dark:from-blue-900/20 dark:via-purple-900/20 dark:to-indigo-900/20 rounded-2xl p-8 border border-blue-200 dark:border-blue-700"
              >
                <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                  <div className="space-y-2">
                    <div className="text-4xl font-bold text-blue-600">{finalScore}%</div>
                    <div className="text-sm font-medium text-blue-800 dark:text-blue-200">Final Score</div>
                  </div>
                  <div className="space-y-2">
                    <div className="text-4xl font-bold text-green-600">{accuracy}</div>
                    <div className="text-sm font-medium text-green-800 dark:text-green-200">Correct</div>
                  </div>
                  <div className="space-y-2">
                    <div className="text-4xl font-bold text-purple-600">{totalTimeSpent}m</div>
                    <div className="text-sm font-medium text-purple-800 dark:text-purple-200">Time Spent</div>
                  </div>
                  <div className="space-y-2">
                    <div className="text-4xl font-bold text-orange-600">{perfectAnswers}</div>
                    <div className="text-sm font-medium text-orange-800 dark:text-orange-200">Perfect</div>
                  </div>
                </div>

                <div className="mt-6">
                  <div className="text-lg font-semibold mb-2">
                    {finalScore >= 90
                      ? "Outstanding! 🌟"
                      : finalScore >= 80
                        ? "Excellent work! 🎯"
                        : finalScore >= 70
                          ? "Good job! 👍"
                          : finalScore >= 60
                            ? "Keep practicing! 💪"
                            : "Need more study! 📚"}
                  </div>
                  <Progress value={finalScore} className="h-3" />
                </div>
              </motion.div>

              {/* Answer Review */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.6 }}
                className="space-y-4"
              >
                <h4 className="text-xl font-semibold text-left">Answer Review</h4>
                <div className="space-y-3 max-h-60 overflow-y-auto">
                  {questionsToUse.map((mcq, index) => {
                    const userAnswer = answers[index]
                    const isCorrect = userAnswer === mcq.correctAnswer

                    return (
                      <motion.div
                        key={mcq.id}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.7 + index * 0.1 }}
                        className={`flex items-center space-x-4 p-4 rounded-lg ${
                          isCorrect
                            ? "bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-700"
                            : "bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-700"
                        }`}
                      >
                        <div className="flex-shrink-0">
                          {isCorrect ? (
                            <CheckCircle className="w-6 h-6 text-green-500" />
                          ) : (
                            <XCircle className="w-6 h-6 text-red-500" />
                          )}
                        </div>
                        <div className="flex-1 min-w-0 text-left">
                          <p className="font-medium text-sm truncate">
                            Q{index + 1}: {mcq.question}
                          </p>
                          <div className="flex items-center space-x-4 text-xs mt-1">
                            <span
                              className={
                                isCorrect ? "text-green-600 dark:text-green-400" : "text-red-600 dark:text-red-400"
                              }
                            >
                              Your answer: {userAnswer !== null ? mcq.options[userAnswer] : "No answer"}
                            </span>
                            {!isCorrect && (
                              <span className="text-green-600 dark:text-green-400">
                                Correct: {mcq.options[mcq.correctAnswer]}
                              </span>
                            )}
                          </div>
                        </div>
                      </motion.div>
                    )
                  })}
                </div>
              </motion.div>

              {/* Action Buttons */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.8 }}
                className="flex justify-center space-x-4"
              >
                <Button variant="outline" onClick={handleClose} className="flex items-center space-x-2">
                  <XCircle className="w-4 h-4" />
                  <span>Close</span>
                </Button>
                <Button onClick={handleRestart} className="flex items-center space-x-2">
                  <RotateCcw className="w-4 h-4" />
                  <span>Retake Quiz</span>
                </Button>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </DialogContent>
    </Dialog>
  )
}
