"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface Test {
  id: string
  name: string
  link: string
  progress: number
  category: string
  color: string
  mcqCount: number
  lastStudied: string
}

interface AddTestDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onAddTest: (test: Omit<Test, "id">) => void
  editTest?: Test | null
  onEditComplete?: () => void
}

const categories = [
  "General Knowledge",
  "English",
  "Mathematics",
  "Pakistan Studies",
  "Current Affairs",
  "Computer Science",
  "Physics",
  "Chemistry",
  "Biology",
  "Economics",
  "Other",
]

const colors = [
  "bg-blue-500",
  "bg-green-500",
  "bg-purple-500",
  "bg-orange-500",
  "bg-red-500",
  "bg-yellow-500",
  "bg-pink-500",
  "bg-indigo-500",
]

export function AddTestDialog({ open, onOpenChange, onAddTest, editTest, onEditComplete }: AddTestDialogProps) {
  const [formData, setFormData] = useState({
    name: "",
    link: "",
    category: "",
    color: "bg-blue-500",
    mcqCount: 100,
  })

  useEffect(() => {
    if (editTest) {
      setFormData({
        name: editTest.name,
        link: editTest.link,
        category: editTest.category,
        color: editTest.color,
        mcqCount: editTest.mcqCount,
      })
    } else {
      setFormData({
        name: "",
        link: "",
        category: "",
        color: "bg-blue-500",
        mcqCount: 100,
      })
    }
  }, [editTest])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!formData.name || !formData.category) return

    const newTest = {
      name: formData.name,
      link: formData.link || "#",
      progress: editTest?.progress || 0,
      category: formData.category,
      color: formData.color,
      mcqCount: formData.mcqCount,
      lastStudied: editTest?.lastStudied || "Never",
    }

    onAddTest(newTest)
    onOpenChange(false)
    onEditComplete?.()

    // Reset form
    setFormData({
      name: "",
      link: "",
      category: "",
      color: "bg-blue-500",
      mcqCount: 100,
    })
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{editTest ? "Edit Test" : "Add New Test"}</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Test Name *</Label>
            <Input
              id="name"
              placeholder="e.g., PPSC General Knowledge"
              value={formData.name}
              onChange={(e) => setFormData((prev) => ({ ...prev, name: e.target.value }))}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="category">Category *</Label>
            <Select
              value={formData.category}
              onValueChange={(value) => setFormData((prev) => ({ ...prev, category: value }))}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select a category" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((category) => (
                  <SelectItem key={category} value={category}>
                    {category}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="link">Study Material Link</Label>
            <Input
              id="link"
              type="url"
              placeholder="https://example.com/study-material"
              value={formData.link}
              onChange={(e) => setFormData((prev) => ({ ...prev, link: e.target.value }))}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="mcqCount">Number of MCQs</Label>
            <Input
              id="mcqCount"
              type="number"
              min="1"
              max="1000"
              value={formData.mcqCount}
              onChange={(e) => setFormData((prev) => ({ ...prev, mcqCount: Number.parseInt(e.target.value) || 100 }))}
            />
          </div>

          <div className="space-y-2">
            <Label>Color Theme</Label>
            <div className="flex flex-wrap gap-2">
              {colors.map((color) => (
                <button
                  key={color}
                  type="button"
                  className={`w-8 h-8 rounded-full ${color} border-2 ${
                    formData.color === color ? "border-gray-900 dark:border-white" : "border-gray-300"
                  } hover:scale-110 transition-transform duration-200`}
                  onClick={() => setFormData((prev) => ({ ...prev, color }))}
                />
              ))}
            </div>
          </div>

          <div className="flex justify-end space-x-2 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit">{editTest ? "Update Test" : "Add Test"}</Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}
