"use client"

import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
} from "recharts"
import { TrendingUp, Clock, Target, Brain, Calendar, Award, Zap, BookOpen } from "lucide-react"

interface Test {
  id: string
  name: string
  category: string
  averageScore: number
  timeSpent: number
  attempts: number
  bestScore: number
  difficulty: "Easy" | "Medium" | "Hard"
}

interface ProgressData {
  date: string
  score: number
  timeSpent: number
  accuracy: number
}

interface AnalyticsDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  tests: Test[]
  progressData: ProgressData[]
}

export function AnalyticsDialog({ open, onOpenChange, tests, progressData }: AnalyticsDialogProps) {
  // Calculate analytics data
  const totalStudyTime = tests.reduce((acc, test) => acc + test.timeSpent, 0)
  const averageScore = tests.reduce((acc, test) => acc + test.averageScore, 0) / tests.length || 0
  const totalAttempts = tests.reduce((acc, test) => acc + test.attempts, 0)
  const bestOverallScore = Math.max(...tests.map((test) => test.bestScore))

  // Category performance data
  const categoryPerformance = tests.reduce(
    (acc, test) => {
      const existing = acc.find((item) => item.category === test.category)
      if (existing) {
        existing.averageScore = (existing.averageScore + test.averageScore) / 2
        existing.timeSpent += test.timeSpent
        existing.attempts += test.attempts
      } else {
        acc.push({
          category: test.category,
          averageScore: test.averageScore,
          timeSpent: test.timeSpent,
          attempts: test.attempts,
        })
      }
      return acc
    },
    [] as Array<{ category: string; averageScore: number; timeSpent: number; attempts: number }>,
  )

  // Difficulty distribution
  const difficultyData = [
    { name: "Easy", value: tests.filter((t) => t.difficulty === "Easy").length, color: "#10b981" },
    { name: "Medium", value: tests.filter((t) => t.difficulty === "Medium").length, color: "#f59e0b" },
    { name: "Hard", value: tests.filter((t) => t.difficulty === "Hard").length, color: "#ef4444" },
  ]

  // Performance radar data
  const radarData = [
    { subject: "Speed", A: 80, fullMark: 100 },
    { subject: "Accuracy", A: averageScore, fullMark: 100 },
    { subject: "Consistency", A: 75, fullMark: 100 },
    { subject: "Retention", A: 85, fullMark: 100 },
    { subject: "Focus", A: 70, fullMark: 100 },
    { subject: "Improvement", A: 90, fullMark: 100 },
  ]

  // Weekly study pattern
  const weeklyPattern = [
    { day: "Mon", hours: 1.2 },
    { day: "Tue", hours: 2.1 },
    { day: "Wed", hours: 0.8 },
    { day: "Thu", hours: 1.9 },
    { day: "Fri", hours: 2.5 },
    { day: "Sat", hours: 3.2 },
    { day: "Sun", hours: 1.8 },
  ]

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-6xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center">
              <TrendingUp className="w-6 h-6 text-white" />
            </div>
            <div>
              <span className="text-2xl font-bold">Learning Analytics</span>
              <p className="text-sm text-gray-500 dark:text-gray-400 font-normal">
                Detailed insights into your study performance
              </p>
            </div>
          </DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="performance">Performance</TabsTrigger>
            <TabsTrigger value="patterns">Patterns</TabsTrigger>
            <TabsTrigger value="insights">Insights</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {/* Key Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Card className="bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-900/20 dark:to-blue-800/20 border-blue-200 dark:border-blue-700">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-blue-600 dark:text-blue-400">Total Study Time</p>
                      <p className="text-3xl font-bold text-blue-700 dark:text-blue-300">
                        {Math.round(totalStudyTime / 60)}h
                      </p>
                      <p className="text-xs text-blue-500 dark:text-blue-400">{totalStudyTime} minutes</p>
                    </div>
                    <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center">
                      <Clock className="w-6 h-6 text-white" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-green-50 to-green-100 dark:from-green-900/20 dark:to-green-800/20 border-green-200 dark:border-green-700">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-green-600 dark:text-green-400">Average Score</p>
                      <p className="text-3xl font-bold text-green-700 dark:text-green-300">
                        {Math.round(averageScore)}%
                      </p>
                      <p className="text-xs text-green-500 dark:text-green-400">across all tests</p>
                    </div>
                    <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center">
                      <Target className="w-6 h-6 text-white" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-900/20 dark:to-purple-800/20 border-purple-200 dark:border-purple-700">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-purple-600 dark:text-purple-400">Total Attempts</p>
                      <p className="text-3xl font-bold text-purple-700 dark:text-purple-300">{totalAttempts}</p>
                      <p className="text-xs text-purple-500 dark:text-purple-400">quiz attempts</p>
                    </div>
                    <div className="w-12 h-12 bg-purple-500 rounded-full flex items-center justify-center">
                      <BookOpen className="w-6 h-6 text-white" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-orange-50 to-orange-100 dark:from-orange-900/20 dark:to-orange-800/20 border-orange-200 dark:border-orange-700">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-orange-600 dark:text-orange-400">Best Score</p>
                      <p className="text-3xl font-bold text-orange-700 dark:text-orange-300">{bestOverallScore}%</p>
                      <p className="text-xs text-orange-500 dark:text-orange-400">personal best</p>
                    </div>
                    <div className="w-12 h-12 bg-orange-500 rounded-full flex items-center justify-center">
                      <Award className="w-6 h-6 text-white" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Category Performance */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Brain className="w-5 h-5 text-blue-600" />
                  <span>Performance by Category</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={categoryPerformance}>
                      <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                      <XAxis dataKey="category" />
                      <YAxis />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "rgba(255, 255, 255, 0.95)",
                          border: "1px solid #e5e7eb",
                          borderRadius: "8px",
                          boxShadow: "0 4px 6px -1px rgba(0, 0, 0, 0.1)",
                        }}
                      />
                      <Bar dataKey="averageScore" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="performance" className="space-y-6">
            {/* Performance Radar */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Zap className="w-5 h-5 text-purple-600" />
                  <span>Performance Radar</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <RadarChart data={radarData}>
                      <PolarGrid />
                      <PolarAngleAxis dataKey="subject" />
                      <PolarRadiusAxis angle={90} domain={[0, 100]} />
                      <Radar
                        name="Performance"
                        dataKey="A"
                        stroke="#8b5cf6"
                        fill="#8b5cf6"
                        fillOpacity={0.3}
                        strokeWidth={2}
                      />
                    </RadarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* Difficulty Distribution */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Target className="w-5 h-5 text-green-600" />
                  <span>Test Difficulty Distribution</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={difficultyData}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={100}
                        paddingAngle={5}
                        dataKey="value"
                      >
                        {difficultyData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <div className="grid grid-cols-3 gap-4 mt-4">
                  {difficultyData.map((difficulty, index) => (
                    <div key={index} className="flex items-center space-x-2">
                      <div className="w-3 h-3 rounded-full" style={{ backgroundColor: difficulty.color }} />
                      <span className="text-sm font-medium">{difficulty.name}</span>
                      <Badge variant="secondary">{difficulty.value}</Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="patterns" className="space-y-6">
            {/* Weekly Study Pattern */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Calendar className="w-5 h-5 text-blue-600" />
                  <span>Weekly Study Pattern</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={weeklyPattern}>
                      <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                      <XAxis dataKey="day" />
                      <YAxis />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "rgba(255, 255, 255, 0.95)",
                          border: "1px solid #e5e7eb",
                          borderRadius: "8px",
                        }}
                      />
                      <Bar dataKey="hours" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* Progress Trend */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <TrendingUp className="w-5 h-5 text-green-600" />
                  <span>Progress Trend</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={progressData}>
                      <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                      <XAxis dataKey="date" />
                      <YAxis />
                      <Tooltip />
                      <Line
                        type="monotone"
                        dataKey="score"
                        stroke="#3b82f6"
                        strokeWidth={3}
                        dot={{ fill: "#3b82f6", strokeWidth: 2, r: 6 }}
                        name="Score %"
                      />
                      <Line
                        type="monotone"
                        dataKey="accuracy"
                        stroke="#10b981"
                        strokeWidth={3}
                        dot={{ fill: "#10b981", strokeWidth: 2, r: 6 }}
                        name="Accuracy %"
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="insights" className="space-y-6">
            {/* AI-Powered Insights */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 border-green-200 dark:border-green-700">
                <CardContent className="p-6">
                  <div className="space-y-3">
                    <div className="flex items-center space-x-2">
                      <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
                        <TrendingUp className="w-4 h-4 text-white" />
                      </div>
                      <h3 className="font-semibold text-green-800 dark:text-green-200">Strengths</h3>
                    </div>
                    <ul className="space-y-2 text-sm text-green-700 dark:text-green-300">
                      <li>• Consistent study schedule on weekends</li>
                      <li>• Strong performance in Pakistan Studies</li>
                      <li>• Improving accuracy over time</li>
                      <li>• Good retention rate</li>
                    </ul>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-orange-50 to-red-50 dark:from-orange-900/20 dark:to-red-900/20 border-orange-200 dark:border-orange-700">
                <CardContent className="p-6">
                  <div className="space-y-3">
                    <div className="flex items-center space-x-2">
                      <div className="w-8 h-8 bg-orange-500 rounded-full flex items-center justify-center">
                        <Target className="w-4 h-4 text-white" />
                      </div>
                      <h3 className="font-semibold text-orange-800 dark:text-orange-200">Areas to Improve</h3>
                    </div>
                    <ul className="space-y-2 text-sm text-orange-700 dark:text-orange-300">
                      <li>• Focus more on Current Affairs</li>
                      <li>• Increase weekday study time</li>
                      <li>• Work on speed in English tests</li>
                      <li>• Review incorrect answers more</li>
                    </ul>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20 border-blue-200 dark:border-blue-700">
                <CardContent className="p-6">
                  <div className="space-y-3">
                    <div className="flex items-center space-x-2">
                      <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center">
                        <Brain className="w-4 h-4 text-white" />
                      </div>
                      <h3 className="font-semibold text-blue-800 dark:text-blue-200">Recommendations</h3>
                    </div>
                    <ul className="space-y-2 text-sm text-blue-700 dark:text-blue-300">
                      <li>• Set daily 30-minute study goals</li>
                      <li>• Use spaced repetition for weak topics</li>
                      <li>• Take practice tests under time pressure</li>
                      <li>• Join study groups for motivation</li>
                    </ul>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-900/20 dark:to-pink-900/20 border-purple-200 dark:border-purple-700">
                <CardContent className="p-6">
                  <div className="space-y-3">
                    <div className="flex items-center space-x-2">
                      <div className="w-8 h-8 bg-purple-500 rounded-full flex items-center justify-center">
                        <Zap className="w-4 h-4 text-white" />
                      </div>
                      <h3 className="font-semibold text-purple-800 dark:text-purple-200">Next Goals</h3>
                    </div>
                    <ul className="space-y-2 text-sm text-purple-700 dark:text-purple-300">
                      <li>• Achieve 90% average score</li>
                      <li>• Complete 100 total quiz attempts</li>
                      <li>• Maintain 14-day study streak</li>
                      <li>• Master all difficulty levels</li>
                    </ul>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  )
}
