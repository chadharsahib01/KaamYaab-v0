class ApiServiceClass {
  private baseUrl: string
  private apiKey: string

  constructor() {
    this.baseUrl = process.env.NEXT_PUBLIC_API_URL || "http://localhost:3001/api"
    this.apiKey = process.env.NEXT_PUBLIC_API_KEY || "admin-api-key"
  }

  private async request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const url = `${this.baseUrl}${endpoint}`

    const config: RequestInit = {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${this.apiKey}`,
        "X-Admin-Access": "true",
        ...options.headers,
      },
      ...options,
    }

    const response = await fetch(url, config)

    if (!response.ok) {
      throw new Error(`API Error: ${response.status} ${response.statusText}`)
    }

    return response.json()
  }

  // MCQ Operations
  async getMCQs() {
    return this.request("/mcqs")
  }

  async createMCQ(mcq: any) {
    return this.request("/mcqs", {
      method: "POST",
      body: JSON.stringify(mcq),
    })
  }

  async updateMCQ(id: string, mcq: any) {
    return this.request(`/mcqs/${id}`, {
      method: "PUT",
      body: JSON.stringify(mcq),
    })
  }

  async deleteMCQ(id: string) {
    return this.request(`/mcqs/${id}`, {
      method: "DELETE",
    })
  }

  async bulkImportMCQs(formData: FormData) {
    return this.request("/mcqs/bulk-import", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${this.apiKey}`,
        // Don't set Content-Type for FormData
      },
      body: formData,
    })
  }

  // Exam Operations
  async getExams() {
    return this.request("/exams")
  }

  async createExam(exam: any) {
    return this.request("/exams", {
      method: "POST",
      body: JSON.stringify(exam),
    })
  }

  async updateExam(id: string, exam: any) {
    return this.request(`/exams/${id}`, {
      method: "PUT",
      body: JSON.stringify(exam),
    })
  }

  async deleteExam(id: string) {
    return this.request(`/exams/${id}`, {
      method: "DELETE",
    })
  }

  // Analytics
  async getStats() {
    return this.request("/stats")
  }

  async getUserAnalytics() {
    return this.request("/analytics/users")
  }

  async getTestAnalytics() {
    return this.request("/analytics/tests")
  }

  // Export
  async exportData() {
    const response = await fetch(`${this.baseUrl}/export`, {
      headers: {
        Authorization: `Bearer ${this.apiKey}`,
      },
    })

    if (response.ok) {
      const blob = await response.blob()
      const url = window.URL.createObjectURL(blob)
      const a = document.createElement("a")
      a.href = url
      a.download = `kaamyaab-data-${new Date().toISOString().split("T")[0]}.json`
      document.body.appendChild(a)
      a.click()
      window.URL.revokeObjectURL(url)
      document.body.removeChild(a)
    }
  }
}

export const ApiService = new ApiServiceClass()
