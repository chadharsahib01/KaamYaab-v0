"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import {
  Plus,
  Edit,
  Trash2,
  Save,
  Upload,
  Download,
  BookOpen,
  Calendar,
  BarChart3,
  Settings,
  Target,
  Search,
  Eye,
  Users,
  Database,
  Wifi,
  WifiOff,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { MaterialCard } from "@/components/material-card"
import { Switch } from "@/components/ui/switch"
import { useToast } from "@/components/ui/use-toast"
import { ApiService } from "@/lib/api-service"
import { WebSocketService } from "@/lib/websocket-service"

interface MCQ {
  id: string
  question: string
  options: string[]
  correctAnswer: number
  explanation: string
  category: string
  difficulty: "Easy" | "Medium" | "Hard"
  subject: string
  createdAt: string
  updatedAt: string
  isActive: boolean
  createdBy: string
}

interface UpcomingExam {
  id: string
  title: string
  date: string
  time: string
  location: string
  category: string
  applicationDeadline: string
  fee: string
  posts: number
  description: string
  isActive: boolean
  createdAt: string
  updatedAt: string
  createdBy: string
}

interface AdminStats {
  totalMCQs: number
  activeMCQs: number
  totalExams: number
  activeExams: number
  totalUsers: number
  activeUsers: number
  testsToday: number
  avgScore: number
}

export default function AdminDashboard() {
  const [mcqs, setMCQs] = useState<MCQ[]>([])
  const [exams, setExams] = useState<UpcomingExam[]>([])
  const [stats, setStats] = useState<AdminStats | null>(null)
  const [activeTab, setActiveTab] = useState("dashboard")
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [isAddMCQOpen, setIsAddMCQOpen] = useState(false)
  const [isAddExamOpen, setIsAddExamOpen] = useState(false)
  const [editingMCQ, setEditingMCQ] = useState<MCQ | null>(null)
  const [editingExam, setEditingExam] = useState<UpcomingExam | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [isConnected, setIsConnected] = useState(false)
  const { toast } = useToast()

  const [newMCQ, setNewMCQ] = useState<Partial<MCQ>>({
    question: "",
    options: ["", "", "", ""],
    correctAnswer: 0,
    explanation: "",
    category: "PPSC",
    difficulty: "Easy",
    subject: "",
    isActive: true,
  })

  const [newExam, setNewExam] = useState<Partial<UpcomingExam>>({
    title: "",
    date: "",
    time: "",
    location: "",
    category: "PPSC",
    applicationDeadline: "",
    fee: "",
    posts: 0,
    description: "",
    isActive: true,
  })

  // Initialize WebSocket connection
  useEffect(() => {
    const wsService = WebSocketService.getInstance()

    wsService.connect("ws://localhost:8080/admin")

    wsService.on("connect", () => {
      setIsConnected(true)
      toast({
        title: "Connected",
        description: "Real-time sync is active",
        variant: "default",
      })
    })

    wsService.on("disconnect", () => {
      setIsConnected(false)
      toast({
        title: "Disconnected",
        description: "Real-time sync is offline",
        variant: "destructive",
      })
    })

    wsService.on("mcq_updated", (data) => {
      setMCQs((prev) => prev.map((mcq) => (mcq.id === data.id ? data : mcq)))
      toast({
        title: "MCQ Updated",
        description: "Changes synced across all apps",
      })
    })

    wsService.on("exam_updated", (data) => {
      setExams((prev) => prev.map((exam) => (exam.id === data.id ? data : exam)))
      toast({
        title: "Exam Updated",
        description: "Changes synced across all apps",
      })
    })

    wsService.on("stats_updated", (data) => {
      setStats(data)
    })

    return () => {
      wsService.disconnect()
    }
  }, [toast])

  // Load initial data
  useEffect(() => {
    loadData()
  }, [])

  const loadData = async () => {
    try {
      setIsLoading(true)
      const [mcqsData, examsData, statsData] = await Promise.all([
        ApiService.getMCQs(),
        ApiService.getExams(),
        ApiService.getStats(),
      ])

      setMCQs(mcqsData)
      setExams(examsData)
      setStats(statsData)
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to load data",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleAddMCQ = async () => {
    if (!newMCQ.question || !newMCQ.options?.every((opt) => opt.trim()) || !newMCQ.explanation) {
      toast({
        title: "Validation Error",
        description: "Please fill all required fields",
        variant: "destructive",
      })
      return
    }

    try {
      const mcqData = {
        ...newMCQ,
        createdBy: "admin", // In real app, get from auth
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      }

      const newMCQResponse = await ApiService.createMCQ(mcqData)
      setMCQs((prev) => [...prev, newMCQResponse])

      // Reset form
      setNewMCQ({
        question: "",
        options: ["", "", "", ""],
        correctAnswer: 0,
        explanation: "",
        category: "PPSC",
        difficulty: "Easy",
        subject: "",
        isActive: true,
      })

      setIsAddMCQOpen(false)

      toast({
        title: "Success",
        description: "MCQ created and synced to user app",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create MCQ",
        variant: "destructive",
      })
    }
  }

  const handleAddExam = async () => {
    if (!newExam.title || !newExam.date || !newExam.time) {
      toast({
        title: "Validation Error",
        description: "Please fill all required fields",
        variant: "destructive",
      })
      return
    }

    try {
      const examData = {
        ...newExam,
        createdBy: "admin",
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      }

      const newExamResponse = await ApiService.createExam(examData)
      setExams((prev) => [...prev, newExamResponse])

      setNewExam({
        title: "",
        date: "",
        time: "",
        location: "",
        category: "PPSC",
        applicationDeadline: "",
        fee: "",
        posts: 0,
        description: "",
        isActive: true,
      })

      setIsAddExamOpen(false)

      toast({
        title: "Success",
        description: "Exam created and synced to user app",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create exam",
        variant: "destructive",
      })
    }
  }

  const handleDeleteMCQ = async (id: string) => {
    try {
      await ApiService.deleteMCQ(id)
      setMCQs((prev) => prev.filter((mcq) => mcq.id !== id))

      toast({
        title: "Success",
        description: "MCQ deleted and synced",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete MCQ",
        variant: "destructive",
      })
    }
  }

  const handleDeleteExam = async (id: string) => {
    try {
      await ApiService.deleteExam(id)
      setExams((prev) => prev.filter((exam) => exam.id !== id))

      toast({
        title: "Success",
        description: "Exam deleted and synced",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete exam",
        variant: "destructive",
      })
    }
  }

  const handleToggleMCQStatus = async (id: string) => {
    try {
      const mcq = mcqs.find((m) => m.id === id)
      if (!mcq) return

      const updatedMCQ = { ...mcq, isActive: !mcq.isActive, updatedAt: new Date().toISOString() }
      await ApiService.updateMCQ(id, updatedMCQ)

      setMCQs((prev) => prev.map((m) => (m.id === id ? updatedMCQ : m)))

      toast({
        title: "Success",
        description: `MCQ ${updatedMCQ.isActive ? "activated" : "deactivated"}`,
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update MCQ status",
        variant: "destructive",
      })
    }
  }

  const handleBulkImport = async (file: File) => {
    try {
      const formData = new FormData()
      formData.append("file", file)

      const result = await ApiService.bulkImportMCQs(formData)

      setMCQs((prev) => [...prev, ...result.imported])

      toast({
        title: "Import Complete",
        description: `${result.imported.length} MCQs imported successfully`,
      })
    } catch (error) {
      toast({
        title: "Import Failed",
        description: "Failed to import MCQs",
        variant: "destructive",
      })
    }
  }

  const filteredMCQs = mcqs.filter((mcq) => {
    const matchesSearch =
      mcq.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
      mcq.subject.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesCategory = selectedCategory === "all" || mcq.category === selectedCategory
    return matchesSearch && matchesCategory
  })

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 dark:from-gray-950 dark:via-blue-950 dark:to-indigo-950 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-lg font-medium">Loading Admin Dashboard...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 dark:from-gray-950 dark:via-blue-950 dark:to-indigo-950">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/90 dark:bg-gray-900/90 backdrop-blur-xl border-b border-gray-200/50 dark:border-gray-700/50 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-gradient-to-r from-purple-600 to-pink-600 rounded-xl flex items-center justify-center shadow-lg">
                  <Settings className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h1 className="text-xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                    KaamYaab Admin
                  </h1>
                  <p className="text-xs text-gray-500 dark:text-gray-400 flex items-center space-x-2">
                    <span>Content Management System</span>
                    <div className="flex items-center space-x-1">
                      {isConnected ? (
                        <Wifi className="w-3 h-3 text-green-500" />
                      ) : (
                        <WifiOff className="w-3 h-3 text-red-500" />
                      )}
                      <span className={isConnected ? "text-green-500" : "text-red-500"}>
                        {isConnected ? "Live" : "Offline"}
                      </span>
                    </div>
                  </p>
                </div>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <input
                type="file"
                accept=".csv,.xlsx,.json"
                onChange={(e) => e.target.files?.[0] && handleBulkImport(e.target.files[0])}
                className="hidden"
                id="bulk-import"
              />
              <Button variant="outline" size="sm" onClick={() => document.getElementById("bulk-import")?.click()}>
                <Upload className="w-4 h-4 mr-2" />
                Import Data
              </Button>
              <Button variant="outline" size="sm" onClick={() => ApiService.exportData()}>
                <Download className="w-4 h-4 mr-2" />
                Export Data
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-4 mb-8">
            <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
            <TabsTrigger value="mcqs">MCQ Management</TabsTrigger>
            <TabsTrigger value="exams">Exam Management</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard" className="space-y-8">
            {/* Real-time Stats */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
            >
              <MaterialCard>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Total MCQs</p>
                      <p className="text-3xl font-bold text-blue-600">{stats?.totalMCQs || 0}</p>
                      <p className="text-xs text-green-600">{stats?.activeMCQs || 0} active</p>
                    </div>
                    <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-blue-600 rounded-xl flex items-center justify-center">
                      <BookOpen className="w-6 h-6 text-white" />
                    </div>
                  </div>
                </CardContent>
              </MaterialCard>

              <MaterialCard>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Active Users</p>
                      <p className="text-3xl font-bold text-green-600">{stats?.activeUsers || 0}</p>
                      <p className="text-xs text-green-600">{stats?.totalUsers || 0} total</p>
                    </div>
                    <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-green-600 rounded-xl flex items-center justify-center">
                      <Users className="w-6 h-6 text-white" />
                    </div>
                  </div>
                </CardContent>
              </MaterialCard>

              <MaterialCard>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Tests Today</p>
                      <p className="text-3xl font-bold text-purple-600">{stats?.testsToday || 0}</p>
                      <p className="text-xs text-purple-600">Avg: {stats?.avgScore || 0}%</p>
                    </div>
                    <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-purple-600 rounded-xl flex items-center justify-center">
                      <Target className="w-6 h-6 text-white" />
                    </div>
                  </div>
                </CardContent>
              </MaterialCard>

              <MaterialCard>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Sync Status</p>
                      <p className="text-3xl font-bold text-orange-600">{isConnected ? "Live" : "Offline"}</p>
                      <p className="text-xs text-orange-600">Real-time updates</p>
                    </div>
                    <div className="w-12 h-12 bg-gradient-to-r from-orange-500 to-orange-600 rounded-xl flex items-center justify-center">
                      <Database className="w-6 h-6 text-white" />
                    </div>
                  </div>
                </CardContent>
              </MaterialCard>
            </motion.div>

            {/* Quick Actions */}
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
              <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">Quick Actions</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <MaterialCard
                  className="hover:shadow-lg transition-shadow cursor-pointer"
                  onClick={() => setIsAddMCQOpen(true)}
                >
                  <CardContent className="p-6 text-center">
                    <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-blue-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                      <Plus className="w-6 h-6 text-white" />
                    </div>
                    <h4 className="font-semibold mb-2">Add MCQ</h4>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Create new question</p>
                  </CardContent>
                </MaterialCard>

                <MaterialCard
                  className="hover:shadow-lg transition-shadow cursor-pointer"
                  onClick={() => setIsAddExamOpen(true)}
                >
                  <CardContent className="p-6 text-center">
                    <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-green-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                      <Calendar className="w-6 h-6 text-white" />
                    </div>
                    <h4 className="font-semibold mb-2">Add Exam</h4>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Schedule new exam</p>
                  </CardContent>
                </MaterialCard>

                <MaterialCard className="hover:shadow-lg transition-shadow cursor-pointer">
                  <CardContent className="p-6 text-center">
                    <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-purple-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                      <Upload className="w-6 h-6 text-white" />
                    </div>
                    <h4 className="font-semibold mb-2">Bulk Import</h4>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Import CSV/Excel</p>
                  </CardContent>
                </MaterialCard>

                <MaterialCard className="hover:shadow-lg transition-shadow cursor-pointer">
                  <CardContent className="p-6 text-center">
                    <div className="w-12 h-12 bg-gradient-to-r from-orange-500 to-orange-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                      <BarChart3 className="w-6 h-6 text-white" />
                    </div>
                    <h4 className="font-semibold mb-2">Analytics</h4>
                    <p className="text-sm text-gray-600 dark:text-gray-400">View reports</p>
                  </CardContent>
                </MaterialCard>
              </div>
            </motion.div>
          </TabsContent>

          <TabsContent value="mcqs" className="space-y-6">
            {/* MCQ Management Header */}
            <div className="flex items-center justify-between">
              <h3 className="text-2xl font-bold text-gray-900 dark:text-white">MCQ Management</h3>
              <Button onClick={() => setIsAddMCQOpen(true)} className="bg-gradient-to-r from-blue-500 to-purple-600">
                <Plus className="w-4 h-4 mr-2" />
                Add New MCQ
              </Button>
            </div>

            {/* Filters */}
            <MaterialCard>
              <CardContent className="p-6">
                <div className="flex flex-col md:flex-row gap-4">
                  <div className="flex-1">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                      <Input
                        placeholder="Search MCQs..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="pl-10"
                      />
                    </div>
                  </div>
                  <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                    <SelectTrigger className="w-48">
                      <SelectValue placeholder="Filter by category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Categories</SelectItem>
                      <SelectItem value="PPSC">PPSC</SelectItem>
                      <SelectItem value="FPSC">FPSC</SelectItem>
                      <SelectItem value="CSS">CSS</SelectItem>
                      <SelectItem value="MPT">MPT</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </MaterialCard>

            {/* MCQ List */}
            <div className="space-y-4">
              {filteredMCQs.map((mcq, index) => (
                <MaterialCard key={mcq.id}>
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-3 mb-3">
                          <Badge variant="outline">{mcq.category}</Badge>
                          <Badge
                            variant={
                              mcq.difficulty === "Easy"
                                ? "default"
                                : mcq.difficulty === "Medium"
                                  ? "secondary"
                                  : "destructive"
                            }
                          >
                            {mcq.difficulty}
                          </Badge>
                          <Badge variant="secondary">{mcq.subject}</Badge>
                          <Switch checked={mcq.isActive} onCheckedChange={() => handleToggleMCQStatus(mcq.id)} />
                          <span className="text-xs text-gray-500">
                            Updated: {new Date(mcq.updatedAt).toLocaleDateString()}
                          </span>
                        </div>
                        <h4 className="font-semibold text-lg mb-3">{mcq.question}</h4>
                        <div className="grid grid-cols-2 gap-2 mb-3">
                          {mcq.options.map((option, optIndex) => (
                            <div
                              key={optIndex}
                              className={`p-2 rounded-lg text-sm ${
                                optIndex === mcq.correctAnswer
                                  ? "bg-green-100 dark:bg-green-900/20 border border-green-300 dark:border-green-700"
                                  : "bg-gray-100 dark:bg-gray-800 border border-gray-200 dark:border-gray-700"
                              }`}
                            >
                              <span className="font-medium">{String.fromCharCode(65 + optIndex)}.</span> {option}
                            </div>
                          ))}
                        </div>
                        <p className="text-sm text-gray-600 dark:text-gray-400">
                          <strong>Explanation:</strong> {mcq.explanation}
                        </p>
                      </div>
                      <div className="flex items-center space-x-2 ml-4">
                        <Button variant="outline" size="sm">
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button variant="outline" size="sm">
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => handleDeleteMCQ(mcq.id)}>
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </MaterialCard>
              ))}
            </div>
          </TabsContent>

          {/* Add MCQ Dialog */}
          <Dialog open={isAddMCQOpen} onOpenChange={setIsAddMCQOpen}>
            <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Add New MCQ</DialogTitle>
              </DialogHeader>
              <div className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="category">Category</Label>
                    <Select
                      value={newMCQ.category}
                      onValueChange={(value) => setNewMCQ({ ...newMCQ, category: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="PPSC">PPSC</SelectItem>
                        <SelectItem value="FPSC">FPSC</SelectItem>
                        <SelectItem value="CSS">CSS</SelectItem>
                        <SelectItem value="MPT">MPT</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="difficulty">Difficulty</Label>
                    <Select
                      value={newMCQ.difficulty}
                      onValueChange={(value: "Easy" | "Medium" | "Hard") => setNewMCQ({ ...newMCQ, difficulty: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Easy">Easy</SelectItem>
                        <SelectItem value="Medium">Medium</SelectItem>
                        <SelectItem value="Hard">Hard</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div>
                  <Label htmlFor="subject">Subject</Label>
                  <Input
                    id="subject"
                    value={newMCQ.subject}
                    onChange={(e) => setNewMCQ({ ...newMCQ, subject: e.target.value })}
                    placeholder="e.g., General Knowledge, Pakistan Studies"
                  />
                </div>

                <div>
                  <Label htmlFor="question">Question</Label>
                  <Textarea
                    id="question"
                    value={newMCQ.question}
                    onChange={(e) => setNewMCQ({ ...newMCQ, question: e.target.value })}
                    placeholder="Enter your question here..."
                    rows={3}
                  />
                </div>

                <div>
                  <Label>Options</Label>
                  <div className="space-y-2">
                    {newMCQ.options?.map((option, index) => (
                      <div key={index} className="flex items-center space-x-2">
                        <Input
                          value={option}
                          onChange={(e) => {
                            const newOptions = [...(newMCQ.options || [])]
                            newOptions[index] = e.target.value
                            setNewMCQ({ ...newMCQ, options: newOptions })
                          }}
                          placeholder={`Option ${String.fromCharCode(65 + index)}`}
                        />
                        <Button
                          type="button"
                          variant={newMCQ.correctAnswer === index ? "default" : "outline"}
                          size="sm"
                          onClick={() => setNewMCQ({ ...newMCQ, correctAnswer: index })}
                        >
                          {newMCQ.correctAnswer === index ? "Correct" : "Mark Correct"}
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <Label htmlFor="explanation">Explanation</Label>
                  <Textarea
                    id="explanation"
                    value={newMCQ.explanation}
                    onChange={(e) => setNewMCQ({ ...newMCQ, explanation: e.target.value })}
                    placeholder="Explain why this answer is correct..."
                    rows={3}
                  />
                </div>

                <div className="flex items-center space-x-2">
                  <Switch
                    checked={newMCQ.isActive}
                    onCheckedChange={(checked) => setNewMCQ({ ...newMCQ, isActive: checked })}
                  />
                  <Label>Active</Label>
                </div>

                <div className="flex justify-end space-x-3">
                  <Button variant="outline" onClick={() => setIsAddMCQOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleAddMCQ}>
                    <Save className="w-4 h-4 mr-2" />
                    Save MCQ
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </Tabs>
      </main>
    </div>
  )
}
