"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { motion } from "framer-motion"
import {
  BookOpen,
  Calendar,
  Clock,
  TrendingUp,
  Trophy,
  Flame,
  Target,
  Settings,
  Bell,
  Search,
  Plus,
  BarChart3,
  Play,
  History,
  Shuffle,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { MaterialCard } from "@/components/material-card"
import { ThemeToggle } from "@/components/theme-toggle"
import { RealTimeSync } from "@/components/real-time-sync"
import { UserApiService } from "@/lib/api-service"
import { useToast } from "@/components/ui/use-toast"

const examCategories = [
  {
    id: "ppsc",
    name: "PPSC",
    fullName: "Punjab Public Service Commission",
    icon: "🏛️",
    color: "from-blue-500 to-blue-600",
    progress: 75,
    totalTests: 45,
    completedTests: 34,
    upcomingExams: 3,
    lastScore: 85,
  },
  {
    id: "fpsc",
    name: "FPSC",
    fullName: "Federal Public Service Commission",
    icon: "🎓",
    color: "from-green-500 to-green-600",
    progress: 60,
    totalTests: 38,
    completedTests: 23,
    upcomingExams: 2,
    lastScore: 78,
  },
  {
    id: "css",
    name: "CSS",
    fullName: "Central Superior Services",
    icon: "📜",
    color: "from-purple-500 to-purple-600",
    progress: 45,
    totalTests: 52,
    completedTests: 23,
    upcomingExams: 1,
    lastScore: 72,
  },
]

export default function UserDashboard() {
  const [searchQuery, setSearchQuery] = useState("")
  const [mcqs, setMCQs] = useState([])
  const [exams, setExams] = useState([])
  const [isLoading, setIsLoading] = useState(true)
  const { toast } = useToast()
  const router = useRouter()

  const userPreferences = JSON.parse(localStorage.getItem("kaamyaab_user_preferences") || "{}")
  const userName = userPreferences.name || "Student"

  useEffect(() => {
    loadData()
  }, [])

  const loadData = async () => {
    try {
      setIsLoading(true)
      const [mcqsData, examsData] = await Promise.all([UserApiService.getMCQs(), UserApiService.getExams()])

      setMCQs(mcqsData)
      setExams(examsData)
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to load data",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleMCQUpdate = (updatedMCQ: any) => {
    setMCQs((prev) => {
      const index = prev.findIndex((mcq: any) => mcq.id === updatedMCQ.id)
      if (index >= 0) {
        const newMCQs = [...prev]
        newMCQs[index] = updatedMCQ
        return newMCQs
      } else {
        return [...prev, updatedMCQ]
      }
    })
  }

  const handleExamUpdate = (updatedExam: any) => {
    setExams((prev) => {
      const index = prev.findIndex((exam: any) => exam.id === updatedExam.id)
      if (index >= 0) {
        const newExams = [...prev]
        newExams[index] = updatedExam
        return newExams
      } else {
        return [...prev, updatedExam]
      }
    })
  }

  const handleCategorySelect = (categoryId: string) => {
    router.push(`/test/${categoryId}`)
  }

  const stats = [
    {
      title: "Study Streak",
      value: "7",
      unit: "days",
      icon: Flame,
      color: "from-orange-500 to-red-500",
      change: "+2 from last week",
    },
    {
      title: "Tests Completed",
      value: "89",
      unit: "tests",
      icon: Target,
      color: "from-green-500 to-emerald-500",
      change: "+12 this week",
    },
    {
      title: "Average Score",
      value: "82",
      unit: "%",
      icon: TrendingUp,
      color: "from-blue-500 to-cyan-500",
      change: "+5% improvement",
    },
    {
      title: "Study Time",
      value: "24",
      unit: "hours",
      icon: Clock,
      color: "from-purple-500 to-pink-500",
      change: "This week",
    },
  ]

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 dark:from-gray-950 dark:via-blue-950 dark:to-indigo-950 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-lg font-medium">Loading Dashboard...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 dark:from-gray-950 dark:via-blue-950 dark:to-indigo-950">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/90 dark:bg-gray-900/90 backdrop-blur-xl border-b border-gray-200/50 dark:border-gray-700/50 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <motion.div whileHover={{ scale: 1.05 }} className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
                  <BookOpen className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h1 className="text-xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                    KaamYaab
                  </h1>
                  <p className="text-xs text-gray-500 dark:text-gray-400">Welcome back, {userName}!</p>
                </div>
              </motion.div>
            </div>

            <div className="flex items-center space-x-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Search tests..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 w-64 bg-white/50 dark:bg-gray-800/50 backdrop-blur-sm"
                />
              </div>

              <RealTimeSync onMCQUpdate={handleMCQUpdate} onExamUpdate={handleExamUpdate} onDataRefresh={loadData} />

              <Button variant="ghost" size="icon" className="relative">
                <Bell className="w-5 h-5" />
                <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full animate-pulse" />
              </Button>

              <ThemeToggle />

              <Button variant="ghost" size="icon">
                <Settings className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">Good morning, {userName}! 🌅</h2>
              <p className="text-gray-600 dark:text-gray-400">
                Ready to continue your learning journey? You're doing great!
              </p>
            </div>
            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Button className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700">
                <Plus className="w-4 h-4 mr-2" />
                Start New Test
              </Button>
            </motion.div>
          </div>
        </motion.div>

        {/* Stats Grid */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8"
        >
          {stats.map((stat, index) => {
            const Icon = stat.icon
            return (
              <MaterialCard key={stat.title} delay={index * 0.1}>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">{stat.title}</p>
                      <div className="flex items-baseline space-x-1">
                        <span className="text-3xl font-bold text-gray-900 dark:text-white">{stat.value}</span>
                        <span className="text-sm text-gray-500 dark:text-gray-400">{stat.unit}</span>
                      </div>
                      <p className="text-xs text-green-600 dark:text-green-400 mt-1">{stat.change}</p>
                    </div>
                    <div
                      className={`w-12 h-12 rounded-xl bg-gradient-to-r ${stat.color} flex items-center justify-center shadow-lg`}
                    >
                      <Icon className="w-6 h-6 text-white" />
                    </div>
                  </div>
                </CardContent>
              </MaterialCard>
            )
          })}
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Exam Categories */}
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white">Your Exam Categories</h3>
                <Button variant="outline" size="sm">
                  <BarChart3 className="w-4 h-4 mr-2" />
                  View Analytics
                </Button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {examCategories.map((category, index) => (
                  <MaterialCard key={category.id} delay={0.3 + index * 0.1}>
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex items-center space-x-3">
                          <div className="text-2xl">{category.icon}</div>
                          <div>
                            <h4 className="font-semibold text-lg text-gray-900 dark:text-white">{category.name}</h4>
                            <p className="text-sm text-gray-600 dark:text-gray-400">{category.fullName}</p>
                          </div>
                        </div>
                        <Badge variant="secondary" className="text-xs">
                          {category.progress}%
                        </Badge>
                      </div>

                      <div className="space-y-4">
                        <div>
                          <div className="flex justify-between text-sm mb-2">
                            <span className="text-gray-600 dark:text-gray-400">Progress</span>
                            <span className="font-medium">
                              {category.completedTests}/{category.totalTests} tests
                            </span>
                          </div>
                          <Progress value={category.progress} className="h-2" />
                        </div>

                        <div className="grid grid-cols-3 gap-4 text-center">
                          <div>
                            <div className="text-lg font-bold text-blue-600">{category.lastScore}%</div>
                            <div className="text-xs text-gray-500">Last Score</div>
                          </div>
                          <div>
                            <div className="text-lg font-bold text-green-600">{category.completedTests}</div>
                            <div className="text-xs text-gray-500">Completed</div>
                          </div>
                          <div>
                            <div className="text-lg font-bold text-orange-600">{category.upcomingExams}</div>
                            <div className="text-xs text-gray-500">Upcoming</div>
                          </div>
                        </div>

                        <div className="flex space-x-2 pt-2">
                          <Button size="sm" className="flex-1" onClick={() => handleCategorySelect(category.id)}>
                            <Play className="w-4 h-4 mr-2" />
                            Continue
                          </Button>
                          <Button variant="outline" size="sm">
                            <BarChart3 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </MaterialCard>
                ))}
              </div>
            </motion.div>

            {/* Quick Actions */}
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
              <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">Quick Actions</h3>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <MaterialCard>
                  <CardContent className="p-6 text-center">
                    <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-blue-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                      <Shuffle className="w-6 h-6 text-white" />
                    </div>
                    <h4 className="font-semibold mb-2">Random Test</h4>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                      Take a mixed quiz from all categories
                    </p>
                    <Button size="sm" variant="outline" className="w-full">
                      Start Random Test
                    </Button>
                  </CardContent>
                </MaterialCard>

                <MaterialCard>
                  <CardContent className="p-6 text-center">
                    <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-green-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                      <History className="w-6 h-6 text-white" />
                    </div>
                    <h4 className="font-semibold mb-2">Past Papers</h4>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">Practice with previous exam papers</p>
                    <Button size="sm" variant="outline" className="w-full">
                      Browse Papers
                    </Button>
                  </CardContent>
                </MaterialCard>

                <MaterialCard>
                  <CardContent className="p-6 text-center">
                    <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-purple-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                      <Trophy className="w-6 h-6 text-white" />
                    </div>
                    <h4 className="font-semibold mb-2">Achievements</h4>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">View your progress and badges</p>
                    <Button size="sm" variant="outline" className="w-full">
                      View Achievements
                    </Button>
                  </CardContent>
                </MaterialCard>
              </div>
            </motion.div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Upcoming Exams */}
            <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.3 }}>
              <MaterialCard>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Calendar className="w-5 h-5 text-blue-600" />
                    <span>Upcoming Exams</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {exams.slice(0, 3).map((exam: any) => (
                    <div
                      key={exam.id}
                      className="flex items-start space-x-3 p-3 rounded-lg bg-gray-50 dark:bg-gray-800/50"
                    >
                      <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0" />
                      <div className="flex-1 min-w-0">
                        <h4 className="font-medium text-sm line-clamp-2">{exam.title}</h4>
                        <div className="flex items-center space-x-2 mt-1">
                          <Badge variant="outline" className="text-xs">
                            {exam.category}
                          </Badge>
                          <span className="text-xs text-gray-500">
                            {Math.ceil((new Date(exam.date).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))}{" "}
                            days left
                          </span>
                        </div>
                        <p className="text-xs text-gray-600 dark:text-gray-400 mt-1">
                          {exam.date} • {exam.time}
                        </p>
                      </div>
                    </div>
                  ))}
                  <Button variant="outline" size="sm" className="w-full">
                    View All Exams
                  </Button>
                </CardContent>
              </MaterialCard>
            </motion.div>

            {/* Recent Activity */}
            <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.4 }}>
              <MaterialCard>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Clock className="w-5 h-5 text-green-600" />
                    <span>Recent Activity</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {[
                    { action: "Completed PPSC General Knowledge Test", score: "85%", time: "2 hours ago" },
                    { action: "Started CSS Current Affairs", score: "In Progress", time: "5 hours ago" },
                    { action: "Achieved 7-day study streak", score: "🔥", time: "1 day ago" },
                  ].map((activity, index) => (
                    <div key={index} className="flex items-center space-x-3 text-sm">
                      <div className="w-2 h-2 bg-green-500 rounded-full flex-shrink-0" />
                      <div className="flex-1 min-w-0">
                        <p className="font-medium line-clamp-1">{activity.action}</p>
                        <div className="flex items-center space-x-2 text-xs text-gray-500">
                          <span>{activity.score}</span>
                          <span>•</span>
                          <span>{activity.time}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </MaterialCard>
            </motion.div>
          </div>
        </div>
      </main>
    </div>
  )
}
