class UserApiServiceClass {
  private baseUrl: string

  constructor() {
    this.baseUrl = process.env.NEXT_PUBLIC_API_URL || "http://localhost:3001/api"
  }

  private async request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const url = `${this.baseUrl}${endpoint}`

    const config: RequestInit = {
      headers: {
        "Content-Type": "application/json",
        ...options.headers,
      },
      ...options,
    }

    const response = await fetch(url, config)

    if (!response.ok) {
      throw new Error(`API Error: ${response.status} ${response.statusText}`)
    }

    return response.json()
  }

  // MCQ Operations (Read-only for users)
  async getMCQs(category?: string) {
    const params = category ? `?category=${category}` : ""
    return this.request(`/mcqs${params}`)
  }

  async getMCQById(id: string) {
    return this.request(`/mcqs/${id}`)
  }

  // Exam Operations (Read-only for users)
  async getExams(category?: string) {
    const params = category ? `?category=${category}` : ""
    return this.request(`/exams${params}`)
  }

  // User Operations
  async createUser(userData: any) {
    return this.request("/users", {
      method: "POST",
      body: JSON.stringify(userData),
    })
  }

  async updateUser(id: string, userData: any) {
    return this.request(`/users/${id}`, {
      method: "PUT",
      body: JSON.stringify(userData),
    })
  }

  // Test Session Operations
  async submitTestSession(sessionData: any) {
    return this.request("/test-sessions", {
      method: "POST",
      body: JSON.stringify(sessionData),
    })
  }

  async getUserTestSessions(userId: string) {
    return this.request(`/test-sessions/user/${userId}`)
  }

  // Analytics (User-specific)
  async getUserStats(userId: string) {
    return this.request(`/analytics/user/${userId}`)
  }
}

export const UserApiService = new UserApiServiceClass()
