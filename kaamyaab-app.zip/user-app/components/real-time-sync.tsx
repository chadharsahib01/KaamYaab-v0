"use client"

import { useEffect, useState } from "react"
import { UserWebSocketService } from "@/lib/websocket-service"
import { useToast } from "@/components/ui/use-toast"
import { Badge } from "@/components/ui/badge"
import { Wifi, WifiOff } from "lucide-react"

interface RealTimeSyncProps {
  onMCQUpdate?: (mcq: any) => void
  onExamUpdate?: (exam: any) => void
  onDataRefresh?: () => void
}

export function RealTimeSync({ onMCQUpdate, onExamUpdate, onDataRefresh }: RealTimeSyncProps) {
  const [isConnected, setIsConnected] = useState(false)
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null)
  const { toast } = useToast()

  useEffect(() => {
    const wsService = UserWebSocketService

    // Connect to user WebSocket
    wsService.connect("ws://localhost:8080/user")

    wsService.on("connect", () => {
      setIsConnected(true)
      toast({
        title: "Connected",
        description: "Real-time updates are active",
        variant: "default",
      })
    })

    wsService.on("disconnect", () => {
      setIsConnected(false)
      toast({
        title: "Disconnected",
        description: "Real-time updates are offline",
        variant: "destructive",
      })
    })

    wsService.on("mcq_created", (mcq) => {
      setLastUpdate(new Date())
      onMCQUpdate?.(mcq)
      toast({
        title: "New MCQ Added",
        description: "A new question has been added to the database",
      })
    })

    wsService.on("mcq_updated", (mcq) => {
      setLastUpdate(new Date())
      onMCQUpdate?.(mcq)
      toast({
        title: "MCQ Updated",
        description: "A question has been modified",
      })
    })

    wsService.on("mcq_deleted", (data) => {
      setLastUpdate(new Date())
      onDataRefresh?.()
      toast({
        title: "MCQ Removed",
        description: "A question has been removed from the database",
      })
    })

    wsService.on("exam_created", (exam) => {
      setLastUpdate(new Date())
      onExamUpdate?.(exam)
      toast({
        title: "New Exam Added",
        description: `${exam.title} has been scheduled`,
      })
    })

    wsService.on("exam_updated", (exam) => {
      setLastUpdate(new Date())
      onExamUpdate?.(exam)
      toast({
        title: "Exam Updated",
        description: `${exam.title} details have been modified`,
      })
    })

    wsService.on("exam_deleted", (data) => {
      setLastUpdate(new Date())
      onDataRefresh?.()
      toast({
        title: "Exam Removed",
        description: "An exam has been removed from the schedule",
      })
    })

    wsService.on("mcqs_bulk_imported", (data) => {
      setLastUpdate(new Date())
      onDataRefresh?.()
      toast({
        title: "Bulk Import Complete",
        description: `${data.count} new questions have been added`,
      })
    })

    return () => {
      wsService.disconnect()
    }
  }, [toast, onMCQUpdate, onExamUpdate, onDataRefresh])

  return (
    <div className="flex items-center space-x-2">
      <Badge variant={isConnected ? "default" : "destructive"} className="flex items-center space-x-1">
        {isConnected ? <Wifi className="w-3 h-3" /> : <WifiOff className="w-3 h-3" />}
        <span>{isConnected ? "Live" : "Offline"}</span>
      </Badge>
      {lastUpdate && <span className="text-xs text-gray-500">Last update: {lastUpdate.toLocaleTimeString()}</span>}
    </div>
  )
}
