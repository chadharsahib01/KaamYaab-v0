"use client"

import type React from "react"

import { createContext, useContext, useReducer, type ReactNode } from "react"

interface UserPreferences {
  name: string
  selectedCategories: string[]
  completedAt: string
}

interface AppState {
  isLoading: boolean
  userPreferences: UserPreferences | null
  darkMode: boolean
  notifications: boolean
}

type AppAction =
  | { type: "SET_LOADING"; payload: boolean }
  | { type: "SET_USER_PREFERENCES"; payload: UserPreferences }
  | { type: "TOGGLE_DARK_MODE" }
  | { type: "TOGGLE_NOTIFICATIONS" }

const initialState: AppState = {
  isLoading: true,
  userPreferences: null,
  darkMode: false,
  notifications: true,
}

function appReducer(state: AppState, action: AppAction): AppState {
  switch (action.type) {
    case "SET_LOADING":
      return { ...state, isLoading: action.payload }
    case "SET_USER_PREFERENCES":
      return { ...state, userPreferences: action.payload }
    case "TOGGLE_DARK_MODE":
      return { ...state, darkMode: !state.darkMode }
    case "TOGGLE_NOTIFICATIONS":
      return { ...state, notifications: !state.notifications }
    default:
      return state
  }
}

const AppContext = createContext<{
  state: AppState
  dispatch: React.Dispatch<AppAction>
} | null>(null)

export function AppProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(appReducer, initialState)

  return <AppContext.Provider value={{ state, dispatch }}>{children}</AppContext.Provider>
}

export function useAppContext() {
  const context = useContext(AppContext)
  if (!context) {
    throw new Error("useAppContext must be used within AppProvider")
  }
  return context
}
