#!/bin/bash

echo "🚀 Deploying KaamYaab Platform..."

# Create necessary directories
mkdir -p uploads ssl

# Pull latest images
echo "📦 Pulling latest images..."
docker-compose pull

# Build and start services
echo "🔨 Building and starting services..."
docker-compose up -d --build

# Wait for services to be ready
echo "⏳ Waiting for services to start..."
sleep 30

# Check service health
echo "🔍 Checking service health..."
docker-compose ps

# Test API connectivity
echo "🧪 Testing API connectivity..."
curl -f http://localhost:3001/health || echo "❌ API health check failed"

# Test admin app
echo "🧪 Testing admin app..."
curl -f http://localhost:3002 || echo "❌ Admin app check failed"

# Test user app
echo "🧪 Testing user app..."
curl -f http://localhost:3000 || echo "❌ User app check failed"

echo "✅ Deployment complete!"
echo ""
echo "🌐 Access URLs:"
echo "   User App:  http://localhost:3000"
echo "   Admin App: http://localhost:3002"
echo "   API:       http://localhost:3001"
echo ""
echo "📊 Monitor logs with: docker-compose logs -f"
echo "🛑 Stop services with: docker-compose down"
