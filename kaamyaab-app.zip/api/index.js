const express = require("express")
const cors = require("cors")
const app = express()

// Middleware
app.use(cors())
app.use(express.json())

// API Key validation
const API_KEY = process.env.API_KEY || "kaamyaab-secure-key-2024"

const validateApiKey = (req, res, next) => {
  const apiKey = req.headers["x-api-key"]
  if (apiKey !== API_KEY) {
    return res.status(401).json({ error: "Invalid API key" })
  }
  next()
}

// Sample data
const categories = [
  { id: "math", name: "Mathematics", icon: "📊", questions: 150 },
  { id: "science", name: "Science", icon: "🔬", questions: 120 },
  { id: "english", name: "English", icon: "📚", questions: 100 },
  { id: "history", name: "History", icon: "🏛️", questions: 80 },
  { id: "geography", name: "Geography", icon: "🌍", questions: 90 },
]

const sampleQuestions = {
  math: [
    {
      id: 1,
      question: "What is 15 + 27?",
      options: ["42", "41", "43", "40"],
      correct: 0,
      explanation: "15 + 27 = 42",
    },
    {
      id: 2,
      question: "What is the square root of 64?",
      options: ["6", "7", "8", "9"],
      correct: 2,
      explanation: "√64 = 8",
    },
  ],
  science: [
    {
      id: 1,
      question: "What is the chemical symbol for water?",
      options: ["H2O", "CO2", "NaCl", "O2"],
      correct: 0,
      explanation: "Water is H2O - two hydrogen atoms and one oxygen atom",
    },
  ],
}

// Routes
app.get("/api/health", (req, res) => {
  res.json({ status: "OK", timestamp: new Date().toISOString() })
})

app.get("/api/categories", validateApiKey, (req, res) => {
  res.json(categories)
})

app.get("/api/questions/:category", validateApiKey, (req, res) => {
  const { category } = req.params
  const { count = 10 } = req.query

  const questions = sampleQuestions[category] || []
  const selectedQuestions = questions.slice(0, Number.parseInt(count))

  res.json(selectedQuestions)
})

app.post("/api/submit-test", validateApiKey, (req, res) => {
  const { category, answers, timeSpent } = req.body

  // Calculate score (mock calculation)
  const totalQuestions = answers.length
  const correctAnswers = Math.floor(Math.random() * totalQuestions)
  const score = Math.round((correctAnswers / totalQuestions) * 100)

  res.json({
    success: true,
    score,
    correctAnswers,
    totalQuestions,
    timeSpent,
    category,
  })
})

// Export for Vercel
module.exports = app
